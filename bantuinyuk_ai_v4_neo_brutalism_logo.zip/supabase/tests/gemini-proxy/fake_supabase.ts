// Fake supabase-js untuk uji logika Edge Function (bukan klien asli).
export const state: any = { rpcCalls: [], deleted: [], quotaNull: false, users: { "JWT_USER1": "u-1" } };
export function createClient(_u: string, _k: string) {
  return {
    auth: { getUser: async (jwt: string) => {
      const id = state.users[jwt];
      return id ? { data: { user: { id } }, error: null } : { data: { user: null }, error: { message: "invalid JWT" } };
    } },
    rpc: async (fn: string, args: unknown) => {
      state.rpcCalls.push({ fn, args });
      return state.quotaNull ? { data: null, error: null } : { data: 42, error: null };
    },
    from: (t: string) => ({ delete: () => ({ eq: async (c: string, v: unknown) => { state.deleted.push({ t, c, v }); return { error: null }; } }) }),
  };
}
