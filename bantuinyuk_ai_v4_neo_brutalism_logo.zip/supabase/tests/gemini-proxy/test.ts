import { state } from "./fake_supabase.ts";
Deno.env.set("SUPABASE_URL", "http://x"); Deno.env.set("SUPABASE_SERVICE_ROLE_KEY", "svc");
Deno.env.set("GEMINI_API_KEY", "SECRET-GEMINI"); Deno.env.set("DAILY_LIMIT", "7");
let handler: (r: Request) => Promise<Response>;
(Deno as any).serve = (h: any) => { handler = h; };
await import("../../functions/gemini-proxy/index.ts");

let gemini: { status: number; body: unknown } | "throw" = { status: 200, body: { candidates: [{ content: { parts: [{ text: "Nomor soal: 1\nJawaban: B" }] } }] } };
let geminiCalls: { url: string; headers: any; body: any }[] = [];
globalThis.fetch = (async (url: string, init: any) => {
  geminiCalls.push({ url, headers: init.headers, body: JSON.parse(init.body) });
  if (gemini === "throw") throw new Error("timeout");
  return new Response(JSON.stringify(gemini.body), { status: gemini.status });
}) as any;

const call = (jwt: string | null, body: unknown) => handler(new Request("http://f", {
  method: "POST", headers: { "Content-Type": "application/json", ...(jwt ? { Authorization: `Bearer ${jwt}` } : {}) }, body: JSON.stringify(body) }));
const reset = () => { state.rpcCalls = []; state.deleted = []; state.quotaNull = false; geminiCalls = []; };
let fail = 0;
const check = (name: string, ok: boolean, extra = "") => { console.log(`${ok ? "PASS" : "FAIL"}  ${name} ${extra}`); if (!ok) fail++; };
const ok = { mode: "solve", text: "1. 2+2?\nA. 3\nB. 4" };

reset(); let r = await call(null, ok);
check("tanpa Authorization -> 401, tidak menyentuh kuota/Gemini", r.status === 401 && state.rpcCalls.length === 0 && geminiCalls.length === 0);
reset(); r = await call("ANON_KEY_JWT", ok);
check("JWT tanpa user (anon key) -> 401", r.status === 401 && state.rpcCalls.length === 0 && geminiCalls.length === 0);
reset(); r = await call("JWT_USER1", { mode: "hack", text: "x" });
check("mode tidak dikenal -> 400 dan kuota TIDAK terpakai", r.status === 400 && state.rpcCalls.length === 0);
reset(); r = await call("JWT_USER1", { mode: "ask", text: "x".repeat(8001) });
check("teks terlalu panjang -> 413, kuota tidak terpakai", r.status === 413 && state.rpcCalls.length === 0);
reset(); r = await call("JWT_USER1", { mode: "ask", text: " " });
check("input kosong -> 400", r.status === 400 && state.rpcCalls.length === 0);
reset(); r = await call("JWT_USER1", ok); let j = await r.json();
check("sukses -> 200 + answer", r.status === 200 && j.answer.includes("Jawaban: B"));
check("kuota dipanggil dgn user_id dari JWT & limit dari env", state.rpcCalls[0]?.args.p_user === "u-1" && state.rpcCalls[0]?.args.p_limit === 7 && state.rpcCalls[0]?.args.p_mode === "solve");
check("API key Gemini dikirim via header, tidak bocor ke respons/URL", geminiCalls[0].headers["x-goog-api-key"] === "SECRET-GEMINI" && !JSON.stringify(j).includes("SECRET") && !geminiCalls[0].url.includes("SECRET"));
check("sukses tidak me-refund kuota", state.deleted.length === 0);
reset(); state.quotaNull = true; r = await call("JWT_USER1", ok);
check("kuota habis -> 429 dan Gemini TIDAK dipanggil", r.status === 429 && geminiCalls.length === 0);
reset(); gemini = { status: 500, body: {} }; r = await call("JWT_USER1", ok);
check("Gemini 500 -> 502 + refund kuota", r.status === 502 && state.deleted[0]?.v === 42, JSON.stringify(state.deleted));
reset(); gemini = { status: 429, body: {} }; r = await call("JWT_USER1", ok);
check("Gemini 429 -> 429 + refund", r.status === 429 && state.deleted.length === 1);
reset(); gemini = { status: 200, body: { candidates: [] } }; r = await call("JWT_USER1", ok);
check("respons kosong -> 502 + refund", r.status === 502 && state.deleted.length === 1);
reset(); gemini = "throw"; r = await call("JWT_USER1", ok);
check("timeout/jaringan -> 504 + refund", r.status === 504 && state.deleted.length === 1);
reset(); gemini = { status: 200, body: { candidates: [{ content: { parts: [{ text: "ok" }] } }] } };
r = await call("JWT_USER1", { mode: "ask", text: "lihat", image_b64: "AAAA", mime: "image/jpeg" });
check("gambar diteruskan sebagai inline_data", r.status === 200 && geminiCalls[0].body.contents[0].parts[1].inline_data.data === "AAAA");
r = await handler(new Request("http://f", { method: "GET" }));
check("GET -> 405", r.status === 405);
console.log(fail === 0 ? "\nSEMUA LULUS" : `\n${fail} GAGAL`); Deno.exit(fail ? 1 : 0);
