-- 0002: kuota per user (Supabase Anonymous Sign-In) + dukungan sinkronisasi riwayat.

-- Kuota tidak lagi memakai x-device-id (bisa dipalsukan); sekarang berdasarkan user_id dari JWT.
alter table public.usage_log alter column device_id drop not null;
create index if not exists usage_log_user_idx on public.usage_log (user_id, created_at desc);

-- Kunci sinkronisasi riwayat: ts sisi klien (ms) unik per user, dipakai untuk upsert.
alter table public.qa_history add column if not exists client_ts bigint;
create unique index if not exists qa_history_user_ts_uidx on public.qa_history (user_id, client_ts);

-- Reservasi kuota atomik: hitung + catat dalam satu transaksi dengan advisory lock per user,
-- sehingga request paralel tidak bisa melewati batas. Mengembalikan id baris, atau NULL bila kuota habis.
create or replace function public.consume_quota(p_user uuid, p_mode text, p_limit int, p_window interval default interval '24 hours')
returns bigint
language plpgsql
security definer
set search_path = public
as $$
declare
  used int;
  new_id bigint;
begin
  perform pg_advisory_xact_lock(hashtextextended(p_user::text, 0));
  select count(*) into used from public.usage_log
    where user_id = p_user and created_at >= now() - p_window;
  if used >= p_limit then
    return null;
  end if;
  insert into public.usage_log (user_id, mode) values (p_user, p_mode) returning id into new_id;
  return new_id;
end;
$$;

-- Hanya Edge Function (service role) yang boleh memanggilnya.
revoke all on function public.consume_quota(uuid, text, int, interval) from public, anon, authenticated;
grant execute on function public.consume_quota(uuid, text, int, interval) to service_role;
