-- Floating AI Assistant — skema dasar. Jalankan lewat `supabase db push` atau SQL editor.
create table if not exists public.user_settings (
  user_id uuid primary key references auth.users(id) on delete cascade,
  settings jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

create table if not exists public.qa_history (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  question text not null,
  answer text not null,
  favorite boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists qa_history_user_idx on public.qa_history (user_id, created_at desc);

-- Pencatatan pemakaian untuk kuota. Ditulis HANYA oleh Edge Function (service role).
create table if not exists public.usage_log (
  id bigint generated always as identity primary key,
  device_id text not null,
  user_id uuid references auth.users(id) on delete set null,
  mode text not null,
  created_at timestamptz not null default now()
);
create index if not exists usage_log_device_idx on public.usage_log (device_id, created_at desc);

alter table public.user_settings enable row level security;
alter table public.qa_history   enable row level security;
alter table public.usage_log    enable row level security;

create policy "settings_own" on public.user_settings
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "history_own" on public.qa_history
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "usage_read_own" on public.usage_log
  for select using (auth.uid() = user_id);
-- Tidak ada policy insert/update/delete pada usage_log: hanya service role (Edge Function) yang menulis.
