// Edge Function: proxy aman ke Gemini. API key hanya ada di secret backend.
// Deploy: supabase functions deploy gemini-proxy --no-verify-jwt
// Secrets: supabase secrets set GEMINI_API_KEY=... GEMINI_MODEL=... DAILY_LIMIT=100
import { createClient } from "jsr:@supabase/supabase-js@2";

const MODEL = Deno.env.get("GEMINI_MODEL") ?? "gemini-flash-latest";
const LIMIT = Number(Deno.env.get("DAILY_LIMIT") ?? "100");
const MAX_TEXT = 8000;
const MAX_IMG_B64 = 4_000_000;

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const SUP = "⁰¹²³⁴⁵⁶⁷⁸⁹";
const wrap = (x: string) => (/^[\w.,\u2212-]+$/.test(x.trim()) ? x.trim() : `(${x.trim()})`);

function plainMath(s: string): string {
  let t = s.replace(/\$\$/g, "").replace(/\\[()[\]]/g, "");
  t = t.replace(/\\(?:text|mathrm|mathbf|operatorname)\s*\{([^{}]*)\}/g, "$1");
  for (let i = 0; i < 5; i++) {
    t = t.replace(/\\[dt]?frac\s*\{([^{}]*)\}\s*\{([^{}]*)\}/g, (_m, a, b) => `${wrap(a)}/${wrap(b)}`);
    t = t.replace(/\\sqrt\s*\{([^{}]*)\}/g, "√($1)");
  }
  t = t.replace(/\\(?:left|right|big|Big|,|;|!|quad|qquad)/g, "");
  const sym: Record<string, string> = {
    times: "×", div: "÷", cdot: "·", pm: "±", le: "≤", leq: "≤", ge: "≥", geq: "≥",
    neq: "≠", ne: "≠", approx: "≈", pi: "π", infty: "∞", circ: "°", degree: "°",
    rightarrow: "→", Rightarrow: "⇒", to: "→", alpha: "α", beta: "β", theta: "θ",
    Delta: "Δ", sum: "Σ",
  };
  t = t.replace(/\\([A-Za-z]+)/g, (_m, k) => (k in sym ? sym[k] : k));
  t = t.replace(/\^\s*\{?(\d+)\}?/g, (_m, d) => [...d].map((c) => SUP[Number(c)]).join(""));
  t = t.replace(/\{,\}/g, ",").replace(/\\%/g, "%").replace(/\\\\/g, "\n");
  return t.replace(/\$/g, "");
}

function dropUnreadable(s: string): string {
  if (!s.includes("TIDAK_TERBACA")) return s;
  const blocks = s.split(/(?=^\s*Nomor soal\s*:)/im).filter((b) => b.trim() && !b.includes("TIDAK_TERBACA"));
  return blocks.length ? blocks.map((b) => b.trim()).join("\n\n") : s;
}

const FORMAT =
  "\n\nATURAN FORMAT: Tulis semua matematika sebagai teks biasa, JANGAN pakai LaTeX atau tanda dolar ($). " +
  "Pecahan ditulis a/b, pangkat dengan ² ³ (atau ^ bila perlu), akar dengan √, dan simbol × ÷ ≤ ≥ ≠ π ° langsung. " +
  "Untuk soal hitungan, tampilkan langkah penyelesaian singkat per baris lalu 'Jawaban akhir: ...'.";

const AUTO_ANSWER_PROMPT =
  "Kamu adalah mesin pengambil keputusan untuk fitur aksesibilitas Auto Answer. Analisis teks OCR dan/atau gambar layar saat ini. " +
  "Keluarkan hanya satu objek JSON sesuai skema yang diberikan, tanpa markdown atau teks tambahan. " +
  "Pilih action='select' hanya jika soal dan opsi terlihat cukup lengkap serta jawaban dapat ditentukan; isi option dengan huruf opsi yang benar. " +
  "Jika opsi tidak memiliki label huruf yang terlihat, atau labelnya ambigu, jangan menebak: gunakan action='none' dan option='NONE'. " +
  "Gunakan action='next' hanya jika layar jelas menunjukkan tombol Next/Lanjutkan/Continue dan tidak ada soal yang belum dijawab pada layar. " +
  "Gunakan action='stop' jika layar meminta konfirmasi, menampilkan hasil akhir, login, pembayaran, izin, atau situasi yang tidak aman/ambigu untuk ditindaklanjuti otomatis. " +
  "Gunakan action='none' jika layar tidak terbaca, tidak ada soal yang dapat dipastikan, atau aksi tidak jelas. " +
  "confidence adalah angka 0 sampai 1. Jika confidence di bawah 0.85, wajib gunakan action='none'. " +
  "should_continue hanya true untuk select/next dengan confidence minimal 0.85; selain itu false. " +
  "Jangan pernah mengarang opsi, menebak berdasarkan posisi tombol, atau menginstruksikan aksi di luar action yang diizinkan.";

const PROMPTS: Record<string, string> = {
  solve:
    "Kamu asisten belajar. Analisis soal berikut dan jawab singkat dalam Bahasa Indonesia dengan format persis:\n" +
    "Nomor soal: <no>\nJawaban: <huruf atau jawaban>\nAlasan: <1-3 kalimat>\n" +
    "Untuk soal hitungan, isi Alasan dengan langkah penyelesaian singkat per baris. Jika ada beberapa soal, ulangi blok itu untuk tiap soal. Abaikan soal yang terpotong di tepi layar atau pilihannya tidak lengkap; " +
    "jawab hanya soal yang lengkap. Hanya jika tidak ada satu pun soal yang lengkap dan terbaca, atau kamu tidak yakin, JANGAN mengarang: tulis hanya TIDAK_TERBACA.",
  explain:
    "Jelaskan dengan lebih detail dan runtut (Bahasa Indonesia, ringkas) mengapa jawaban tersebut benar, termasuk konsep yang mendasarinya.",
  ask: "Jawab pertanyaan pengguna dengan jelas dan ringkas dalam Bahasa Indonesia. Gunakan gambar jika ada.",
  translate:
    "Terjemahkan teks berikut ke Bahasa Indonesia. Jika teks sudah berbahasa Indonesia, terjemahkan ke Bahasa Inggris. Keluarkan hanya hasil terjemahan.",
  auto_answer: AUTO_ANSWER_PROMPT,
};

type AutoAction = {
  action: "select" | "next" | "stop" | "none";
  option: "A" | "B" | "C" | "D" | "E" | "NONE";
  confidence: number;
  should_continue: boolean;
  reason: string;
};

const AUTO_SCHEMA = {
  type: "OBJECT",
  properties: {
    action: { type: "STRING", enum: ["select", "next", "stop", "none"] },
    option: { type: "STRING", enum: ["A", "B", "C", "D", "E", "NONE"] },
    confidence: { type: "NUMBER" },
    should_continue: { type: "BOOLEAN" },
    reason: { type: "STRING" },
  },
  required: ["action", "option", "confidence", "should_continue", "reason"],
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });

function parseAutoAction(raw: string): AutoAction | null {
  try {
    const value = JSON.parse(raw);
    const actions = ["select", "next", "stop", "none"];
    const options = ["A", "B", "C", "D", "E", "NONE"];
    if (!value || !actions.includes(value.action) || !options.includes(value.option)) return null;

    const confidence = Number(value.confidence);
    if (!Number.isFinite(confidence)) return null;
    const boundedConfidence = Math.max(0, Math.min(1, confidence));
    let action = value.action as AutoAction["action"];
    let option = value.option as AutoAction["option"];
    let shouldContinue = value.should_continue === true;
    const reason = typeof value.reason === "string" ? value.reason.slice(0, 500) : "";

    // Validasi server-side tambahan: jangan izinkan aksi berkeyakinan rendah.
    if (boundedConfidence < 0.85) {
      action = "none";
      option = "NONE";
      shouldContinue = false;
    }
    if (action === "select" && option === "NONE") {
      action = "none";
      shouldContinue = false;
    }
    if (action !== "select" && action !== "next") shouldContinue = false;

    return {
      action,
      option,
      confidence: boundedConfidence,
      should_continue: shouldContinue,
      reason,
    };
  } catch {
    return null;
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ error: "method" }, 405);

  // Autentikasi: wajib JWT milik user, anon key saja ditolak.
  const jwt = (req.headers.get("Authorization") ?? "").replace(/^Bearer\s+/i, "").trim();
  if (!jwt) return json({ error: "tidak terautentikasi" }, 401);

  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  const geminiKey = Deno.env.get("GEMINI_API_KEY");
  if (!supabaseUrl || !serviceRoleKey || !geminiKey) {
    return json({ error: "konfigurasi secret backend belum lengkap" }, 500);
  }

  const admin = createClient(supabaseUrl, serviceRoleKey);
  const { data: auth, error: authErr } = await admin.auth.getUser(jwt);
  const userId = auth?.user?.id;
  if (authErr || !userId) return json({ error: "sesi tidak valid" }, 401);

  // Validasi input sebelum kuota digunakan.
  let body: { mode?: string; text?: string; image_b64?: string; mime?: string };
  try {
    body = await req.json();
  } catch {
    return json({ error: "JSON tidak valid" }, 400);
  }

  const mode = body.mode ?? "";
  const text = typeof body.text === "string" ? body.text : "";
  const imageB64 = typeof body.image_b64 === "string" ? body.image_b64 : "";
  const mime = body.mime ?? "image/jpeg";

  if (!Object.hasOwn(PROMPTS, mode)) return json({ error: "mode tidak dikenal" }, 400);
  if (text.length > MAX_TEXT) return json({ error: "teks terlalu panjang" }, 413);
  if (!text.trim() && !imageB64) return json({ error: "input kosong" }, 400);
  if (imageB64.length > MAX_IMG_B64) return json({ error: "gambar terlalu besar" }, 413);
  if (imageB64 && !["image/jpeg", "image/png", "image/webp", "image/heic", "image/heif"].includes(mime)) {
    return json({ error: "format gambar tidak didukung" }, 400);
  }

  // Kuota per user, atomik.
  const { data: usageId, error: qErr } = await admin.rpc("consume_quota", {
    p_user: userId,
    p_mode: mode,
    p_limit: LIMIT,
  });
  if (qErr) return json({ error: "gagal memeriksa kuota" }, 500);
  if (usageId === null) return json({ error: "kuota harian habis" }, 429);
  const refund = async () => {
    await admin.from("usage_log").delete().eq("id", usageId);
  };

  const prompt = mode === "auto_answer"
    ? `${PROMPTS[mode]}\n\nKonteks layar/OCR:\n${text}`
    : `${PROMPTS[mode]}${FORMAT}\n\n${text}`;

  const parts: unknown[] = [{ text: prompt }];
  if (imageB64) parts.push({ inline_data: { mime_type: mime, data: imageB64 } });

  const generationConfig = mode === "auto_answer"
    ? {
      temperature: 0,
      maxOutputTokens: 512,
      responseMimeType: "application/json",
      responseSchema: AUTO_SCHEMA,
    }
    : { temperature: 0.2, maxOutputTokens: 2048 };

  let r: Response;
  try {
    r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-goog-api-key": geminiKey },
      body: JSON.stringify({
        contents: [{ role: "user", parts }],
        generationConfig,
      }),
      signal: AbortSignal.timeout(40_000),
    });
  } catch {
    await refund();
    return json({ error: "Gemini tidak dapat dihubungi / timeout" }, 504);
  }

  if (r.status === 429) {
    await refund();
    return json({ error: "kuota Gemini habis" }, 429);
  }
  if (!r.ok) {
    await refund();
    return json({ error: `Gemini ${r.status}` }, 502);
  }

  let data: any;
  try {
    data = await r.json();
  } catch {
    await refund();
    return json({ error: "respons Gemini tidak valid" }, 502);
  }

  const answer = (data?.candidates?.[0]?.content?.parts ?? [])
    .map((part: { text?: string }) => part.text ?? "")
    .join("")
    .trim();

  if (!answer) {
    await refund();
    return json({ error: "respons kosong" }, 502);
  }

  if (mode === "auto_answer") {
    const action = parseAutoAction(answer);
    if (!action) {
      await refund();
      return json({ error: "format keputusan Auto Answer tidak valid" }, 502);
    }
    return json({ answer: JSON.stringify(action), action });
  }

  const clean = mode === "solve" ? dropUnreadable(plainMath(answer)) : plainMath(answer);
  return json({ answer: clean });
});
