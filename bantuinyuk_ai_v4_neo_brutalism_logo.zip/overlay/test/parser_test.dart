import 'package:flutter_test/flutter_test.dart';
import 'package:floating_ai_assistant/brain/parser.dart';

void main() {
  test('parses question and options', () {
    const t = '1. Ibu kota Indonesia adalah...\nA. Bandung\nB. Jakarta\nC. Medan\n2. 2 + 2 = ?\nA. 3\nB. 4';
    final p = QuestionParser.parse(t);
    expect(p.length, 2);
    expect(p[0].number, '1');
    expect(p[0].options.length, 3);
    expect(p[0].options[1], 'B. Jakarta');
    expect(p[1].options.length, 2);
  });

  test('joins wrapped question lines', () {
    final p = QuestionParser.parse('3. Pernyataan berikut yang benar\nadalah ...\nA. satu\nB. dua');
    expect(p[0].question, 'Pernyataan berikut yang benar adalah ...');
  });

  test('joins wrapped option lines', () {
    final p = QuestionParser.parse('4. Soal\nA. pilihan yang panjang\nsekali lagi\nB. dua');
    expect(p[0].options[0], 'A. pilihan yang panjang sekali lagi');
  });

  test('unreadable text', () {
    expect(QuestionParser.isReadable('~ . ,'), isFalse);
    expect(QuestionParser.isReadable('Soal nomor satu tentang fotosintesis'), isTrue);
  });

  test('needsImage when visual word or nothing parsed', () {
    final withOpts = QuestionParser.parse('1. Perhatikan gambar berikut\nA. a\nB. b');
    expect(QuestionParser.needsImage('1. Perhatikan gambar berikut', withOpts), isTrue);
    final plain = QuestionParser.parse('1. Hitung dua tambah dua\nA. 3\nB. 4');
    expect(QuestionParser.needsImage('1. Hitung dua tambah dua', plain), isFalse);
    expect(QuestionParser.needsImage('teks bebas tanpa nomor', const []), isTrue);
  });

  test('toPrompt formats and falls back to raw text', () {
    final p = QuestionParser.parse('1. Soal satu\nA. a\nB. b');
    expect(QuestionParser.toPrompt(p, 'x'), 'Soal 1: Soal satu\nA. a\nB. b');
    expect(QuestionParser.toPrompt(const [], '  teks mentah  '), 'teks mentah');
  });
}
