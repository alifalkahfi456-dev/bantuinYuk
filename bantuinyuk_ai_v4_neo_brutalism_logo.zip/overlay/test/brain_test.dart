import 'package:flutter_test/flutter_test.dart';
import 'package:floating_ai_assistant/brain/gemini.dart';
import 'package:floating_ai_assistant/brain/store.dart';
import 'package:floating_ai_assistant/brain/supabase.dart';
import 'package:floating_ai_assistant/brain/sync.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Req {
  Req(this.method, this.url, this.headers, this.body);
  final String method;
  final String url;
  final Map<String, String> headers;
  final String? body;
}

class FakeTransport implements Transport {
  FakeTransport(this.script);
  final List<Resp> script;
  final List<Req> log = [];
  @override
  Future<Resp> send(String method, String url, Map<String, String> headers, String? body, {RequestHook? onRequest}) async {
    log.add(Req(method, url, headers, body));
    return script.removeAt(0);
  }
}

class FakeBubble implements BubbleHost {
  FakeBubble(this.state);
  Map<String, dynamic> state;
  Map<String, dynamic>? lastSet;
  @override
  Future<Map<String, dynamic>> getBubble() async => state;
  @override
  Future<void> setBubble(Map<String, dynamic> s) async {
    lastSet = s;
  }
}

int _now() => DateTime.now().millisecondsSinceEpoch ~/ 1000;

Future<Store> _store([Map<String, Object> extra = const {}]) async {
  SharedPreferences.setMockInitialValues({'sb_url': 'https://x.supabase.co', 'sb_key': 'anon', ...extra});
  return Store.open();
}

const _session = '{"access_token":"tok","refresh_token":"ref","expires_in":3600,"user":{"id":"u1"}}';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('ask: sign-in anonim lalu panggil gemini-proxy dengan JWT user', () async {
    final t = FakeTransport([const Resp(200, _session), const Resp(200, '{"answer":" B "}')]);
    final g = GeminiClient(SupabaseApi(await _store(), t));
    expect(await g.ask('ask', 'halo', null), 'B');
    expect(t.log[0].url, 'https://x.supabase.co/auth/v1/signup');
    expect(t.log[1].url, 'https://x.supabase.co/functions/v1/gemini-proxy');
    expect(t.log[1].headers['Authorization'], 'Bearer tok');
  });

  test('ask: 429 menjadi pesan kuota', () async {
    final t = FakeTransport([const Resp(200, _session), const Resp(429, '{}')]);
    final g = GeminiClient(SupabaseApi(await _store(), t));
    await expectLater(g.ask('ask', 'x', null), throwsA(isA<GeminiError>().having((e) => e.message, 'message', contains('Kuota'))));
  });

  test('ask: 401 memicu refresh paksa lalu retry sekali', () async {
    final store = await _store({'sb_access': 'old', 'sb_refresh': 'r', 'sb_exp': _now() + 3600, 'sb_uid': 'u1'});
    final t = FakeTransport([
      const Resp(401, '{}'),
      const Resp(200, '{"access_token":"new","refresh_token":"r2","expires_in":3600}'),
      const Resp(200, '{"answer":"C"}'),
    ]);
    final g = GeminiClient(SupabaseApi(store, t));
    expect(await g.ask('ask', 'x', null), 'C');
    expect(t.log[1].url, contains('grant_type=refresh_token'));
    expect(t.log[2].headers['Authorization'], 'Bearer new');
  });

  test('backend belum diatur → pesan jelas', () async {
    SharedPreferences.setMockInitialValues({});
    final g = GeminiClient(SupabaseApi(await Store.open(), FakeTransport([])));
    await expectLater(g.ask('ask', 'x', null), throwsA(isA<GeminiError>().having((e) => e.message, 'message', contains('Backend belum diatur'))));
  });

  test('riwayat: merge tidak menimpa item lokal dan dibatasi 50', () async {
    final store = await _store();
    await store.addHistory('lokal', 'A', ts: 1000);
    final added = await store.mergeHistory([
      {'ts': 1000, 'q': 'server', 'a': 'X', 'fav': true},
      {'ts': 2000, 'q': 'baru', 'a': 'B', 'fav': false},
    ]);
    expect(added, 1);
    final h = store.history();
    expect(h.map((e) => e['ts']).toList(), [2000, 1000]);
    expect(h.last['q'], 'lokal');
  });

  test('sync: pengaturan server yang lebih baru diterapkan ke bubble', () async {
    final store = await _store({'sb_access': 'tok', 'sb_refresh': 'r', 'sb_exp': _now() + 3600, 'sb_uid': 'u1'});
    final t = FakeTransport([
      const Resp(200, '[{"settings":{"size":80,"alpha":0.5,"color":-1,"shape":2,"ts":2000}}]'),
    ]);
    final bubble = FakeBubble({'size': 64, 'alpha': 0.85, 'color': -12877066, 'shape': 0, 'ts': 1000});
    final msg = await Sync(store, SupabaseApi(store, t), bubble).syncNow();
    expect(msg, contains('diambil dari server'));
    expect(bubble.lastSet!['size'], 80);
    expect(bubble.lastSet!['ts'], 2000);
  });

  test('sync: pengaturan lokal lebih baru dikirim ke server', () async {
    final store = await _store({'sb_access': 'tok', 'sb_refresh': 'r', 'sb_exp': _now() + 3600, 'sb_uid': 'u1'});
    final t = FakeTransport([
      const Resp(200, '[]'),
      const Resp(201, ''),
    ]);
    final bubble = FakeBubble({'size': 64, 'alpha': 0.85, 'color': -12877066, 'shape': 0, 'ts': 5000});
    final msg = await Sync(store, SupabaseApi(store, t), bubble).syncNow();
    expect(msg, contains('dikirim ke server'));
    expect(t.log[1].method, 'POST');
    expect(t.log[1].url, contains('user_settings'));
    expect(bubble.lastSet, isNull);
  });
}
