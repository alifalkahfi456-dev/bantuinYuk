import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'brain/brain.dart';

const _ch = MethodChannel('floating_assistant');
const _palette = [0xFFFFD93D, 0xFFFF6B6B, 0xFF6BCB77, 0xFF4D96FF, 0xFFFF8FAB];
const _shapes = ['Lingkaran', 'Kotak', 'Bulat', 'Segitiga'];
const _ink = Color(0xFF171717);
const _paper = Color(0xFFFFF8E7);
const _yellow = Color(0xFFFFD93D);
const _cyan = _ink;

void main() => runApp(const FloatingApp());

/// Entrypoint FlutterEngine headless milik service overlay (lihat Brain.kt). Tidak ada UI.
@pragma('vm:entry-point')
void brainMain() {
  WidgetsFlutterBinding.ensureInitialized();
  unawaited(Brain().start());
}

class FloatingApp extends StatelessWidget {
  const FloatingApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'bantuinYuk AI',
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(seedColor: _yellow, brightness: Brightness.light, surface: _paper),
          scaffoldBackgroundColor: _paper,
          textTheme: ThemeData.light().textTheme.apply(bodyColor: _ink, displayColor: _ink),
          appBarTheme: const AppBarTheme(backgroundColor: _yellow, foregroundColor: _ink, elevation: 0),
          cardTheme: CardThemeData(color: Colors.white, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4), side: const BorderSide(color: _ink, width: 2))),
          dialogTheme: const DialogThemeData(backgroundColor: _paper, shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(4)), side: BorderSide(color: _ink, width: 2))),
          inputDecorationTheme: const InputDecorationTheme(border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(4)), borderSide: BorderSide(color: _ink, width: 2)), enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(4)), borderSide: BorderSide(color: _ink, width: 2)), focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(4)), borderSide: BorderSide(color: _ink, width: 3))),
          elevatedButtonTheme: ElevatedButtonThemeData(style: ElevatedButton.styleFrom(backgroundColor: _yellow, foregroundColor: _ink, elevation: 3, side: const BorderSide(color: _ink, width: 2), shape: const RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(4)))),),
          outlinedButtonTheme: OutlinedButtonThemeData(style: OutlinedButton.styleFrom(foregroundColor: _ink, side: const BorderSide(color: _ink, width: 2), shape: const RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(4))))),
          snackBarTheme: const SnackBarThemeData(backgroundColor: _ink, contentTextStyle: TextStyle(color: Colors.white)),
        ),
        home: const Splash(),
      );
}

// ---------------------------------------------------------------- splash
class _SparklePainter extends CustomPainter {
  final double glow;
  _SparklePainter(this.glow);
  @override
  void paint(Canvas canvas, Size s) {
    final c = Offset(s.width / 2, s.height / 2);
    final r = s.width / 2;
    canvas.drawCircle(
        c,
        r,
        Paint()
          ..shader = RadialGradient(colors: [
            _cyan.withValues(alpha: .35 * glow),
            Colors.transparent
          ]).createShader(Rect.fromCircle(center: c, radius: r)));
    final k = r * .55;
    final p = Path()
      ..moveTo(c.dx, c.dy - k)
      ..quadraticBezierTo(c.dx, c.dy, c.dx + k, c.dy)
      ..quadraticBezierTo(c.dx, c.dy, c.dx, c.dy + k)
      ..quadraticBezierTo(c.dx, c.dy, c.dx - k, c.dy)
      ..quadraticBezierTo(c.dx, c.dy, c.dx, c.dy - k)
      ..close();
    canvas.drawPath(p, Paint()..color = Colors.white);
  }

  @override
  bool shouldRepaint(_SparklePainter o) => o.glow != glow;
}

class Splash extends StatefulWidget {
  const Splash({super.key});
  @override
  State<Splash> createState() => _SplashState();
}

class _SplashState extends State<Splash> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 1500))
        ..forward().whenComplete(_next);

  void _next() {
    if (!mounted) return;
    Navigator.of(context).pushReplacement(PageRouteBuilder(
      transitionDuration: const Duration(milliseconds: 500),
      pageBuilder: (_, __, ___) => const Dashboard(),
      transitionsBuilder: (_, a, __, child) => FadeTransition(opacity: a, child: child),
    ));
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Center(
          child: AnimatedBuilder(
            animation: _c,
            builder: (_, __) {
              final t = Curves.easeOutBack.transform(math.min(1, _c.value * 1.4));
              return Opacity(
                opacity: math.min(1, _c.value * 2),
                child: Transform.scale(
                  scale: .6 + .4 * t,
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    SizedBox(
                        width: 140,
                        height: 140,
                        child: CustomPaint(painter: _SparklePainter(.6 + .4 * math.sin(_c.value * math.pi)))),
                    const SizedBox(height: 12),
                    const Text('bantuinYuk AI', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 6),
                    Text('Asisten belajar di atas layar',
                        style: TextStyle(color: _ink.withValues(alpha: .68))),
                  ]),
                ),
              );
            },
          ),
        ),
      );
}

// ---------------------------------------------------------------- dashboard
class Dashboard extends StatefulWidget {
  const Dashboard({super.key});
  @override
  State<Dashboard> createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> with WidgetsBindingObserver {
  bool _perm = false, _running = false, _historyOn = false, _stealth = false;
  double _size = 64, _alpha = .85;
  int _color = _palette[0], _shape = 0;
  String _url = '', _key = '';
  String? _banner;
  final _scroll = ScrollController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _scroll.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) {
      _loadCfg();
      _refresh();
    }
  }

  /// Baca ulang konfigurasi dari native. Dipanggil juga saat aplikasi kembali dibuka, karena
  /// bentuk/warna/ukuran bisa diubah dari jendela Pengaturan Bubble di overlay atau lewat sinkronisasi;
  /// tanpa ini slider di sini akan menimpa nilai baru dengan nilai lama.
  Future<Map<String, dynamic>?> _loadCfg() async {
    final c = await _ch.invokeMapMethod<String, dynamic>('getConfig');
    if (c != null && mounted) {
      setState(() {
        _size = (c['size'] as num).toDouble();
        _alpha = (c['alpha'] as num).toDouble();
        _color = (c['color'] as num).toInt();
        _shape = (c['shape'] as num).toInt();
        _stealth = c['stealth'] as bool? ?? false;
        _url = c['sbUrl'] as String? ?? '';
        _key = c['sbKey'] as String? ?? '';
        _historyOn = c['historyOn'] as bool? ?? false;
      });
    }
    return c;
  }

  Future<void> _load() async {
    final c = await _loadCfg();
    if (c != null && mounted && c['accepted'] != true) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _showNotice());
    }
    await _refresh();
  }

  Future<void> _showNotice() async {
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        title: const Text('Sebelum mulai'),
        content: const Text(
            'bantuinYuk AI adalah asisten belajar dan alat bantu umum di atas aplikasi lain.\n\n'
            'Kamu bertanggung jawab mematuhi aturan sekolah, kampus, ujian, atau platform tempat aplikasi ini dipakai. '
            'Aplikasi ini tidak menyembunyikan diri dari pengawasan dan tidak menembus layar yang diblokir aplikasi lain. '
            'Layar hanya dikirim ke server setelah kamu menekan aksi secara eksplisit.'),
        actions: [
          TextButton(
            onPressed: () async {
              await _ch.invokeMethod('setAccepted');
              if (ctx.mounted) Navigator.pop(ctx);
            },
            child: const Text('Saya mengerti'),
          ),
        ],
      ),
    );
  }

  Future<void> _refresh() async {
    final p = await _ch.invokeMethod<bool>('hasOverlayPermission') ?? false;
    final r = await _ch.invokeMethod<bool>('isRunning') ?? false;
    if (mounted) setState(() { _perm = p; _running = r; });
  }

  Map<String, dynamic> get _cfg =>
      {'size': _size.round(), 'alpha': _alpha, 'color': _color, 'shape': _shape, 'stealth': _stealth};

  void _say(String m) => setState(() => _banner = m);

  Future<void> _toggle() async {
    HapticFeedback.mediumImpact();
    if (!_perm) {
      await _ch.invokeMethod('requestOverlayPermission');
      return;
    }
    if (_running) {
      await _ch.invokeMethod('stopBubble');
      _say('Bubble disembunyikan.');
    } else {
      await _ch.invokeMethod('startBubble', _cfg);
      _say('Bubble ditampilkan! Tekan Home untuk lihat.');
    }
    await Future.delayed(const Duration(milliseconds: 200));
    await _refresh();
  }

  Future<void> _openTool(String tool) async {
    HapticFeedback.selectionClick();
    if (!_perm) {
      await _ch.invokeMethod('requestOverlayPermission');
      return;
    }
    await _ch.invokeMethod('openTool', {'tool': tool});
    _say('Alat dibuka! Tekan Home untuk lihat.');
    await Future.delayed(const Duration(milliseconds: 200));
    await _refresh();
  }

  void _push() {
    if (_running) _ch.invokeMethod('updateConfig', _cfg);
  }

  Widget _glass(Widget child, {Color border = _ink}) => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: border == Colors.amber ? const Color(0xFFFFE66D) : Colors.white,
          borderRadius: BorderRadius.circular(4),
          border: Border.all(color: _ink, width: 2),
          boxShadow: const [BoxShadow(color: _ink, offset: Offset(4, 4))],
        ),
        child: child,
      );

  Widget _fadeIn(int i, Widget child) => TweenAnimationBuilder<double>(
        tween: Tween(begin: 0, end: 1),
        duration: Duration(milliseconds: 450 + i * 90),
        curve: Curves.easeOutCubic,
        builder: (_, v, c) => Opacity(opacity: v, child: Transform.translate(offset: Offset(0, 18 * (1 - v)), child: c)),
        child: child,
      );

  void _openSettings() {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: _paper,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(4)), side: BorderSide(color: _ink, width: 2)),
      builder: (_) => _SettingsSheet(
        url: _url,
        anonKey: _key,
        historyOn: _historyOn,
        onSaved: (u, k, h) => setState(() { _url = u; _key = k; _historyOn = h; }),
        onSynced: _loadCfg,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final accent = Color(_color);
    final tiles = [
      ('Browser', Icons.travel_explore_rounded, 'search'),
      ('Terjemahan', Icons.translate_rounded, 'translate'),
      ('Galeri', Icons.photo_library_rounded, 'gallery'),
      ('Gambar', Icons.brush_rounded, 'draw'),
    ];
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [_paper, Color(0xFFFFE66D)]),
        ),
        child: SafeArea(
          child: Column(children: [
            Expanded(
              child: ListView(controller: _scroll, padding: const EdgeInsets.all(20), children: [
                _fadeIn(0, const Text('bantuinYuk AI', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800))),
                const SizedBox(height: 4),
                _fadeIn(0, Text('Asisten belajar mengambang di atas aplikasi lain',
                    style: TextStyle(color: _ink.withValues(alpha: .68)))),
                const SizedBox(height: 18),
                AnimatedSwitcher(
                  duration: const Duration(milliseconds: 300),
                  child: _banner == null
                      ? const SizedBox.shrink()
                      : Padding(
                          key: ValueKey(_banner),
                          padding: const EdgeInsets.only(bottom: 14),
                          child: _glass(Text(_banner!), border: Colors.greenAccent)),
                ),
                if (!_perm)
                  _fadeIn(1, Padding(
                    padding: const EdgeInsets.only(bottom: 14),
                    child: _glass(
                        const Text('Langkah 1: ketuk kartu Floating App Bubble → aktifkan "Tampil di atas aplikasi lain" '
                            'di pengaturan Android → kembali ke sini. Langkah 2: izinkan notifikasi bila diminta.'),
                        border: Colors.amber),
                  )),
                if (_url.isEmpty || _key.isEmpty)
                  _fadeIn(1, Padding(
                    padding: const EdgeInsets.only(bottom: 14),
                    child: GestureDetector(
                      onTap: _openSettings,
                      child: _glass(const Text('Backend Gemini belum diatur. Ketuk ikon pengaturan di bawah lalu isi URL & anon key Supabase.'),
                          border: Colors.amber),
                    ),
                  )),
                _fadeIn(2, GestureDetector(
                  onTap: _toggle,
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 350),
                    curve: Curves.easeOutCubic,
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(4),
                      color: _running ? const Color(0xFFB8F2C2) : Colors.white,
                      border: Border.all(color: _ink, width: 2),
                      boxShadow: const [BoxShadow(color: _ink, offset: Offset(5, 5))],
                    ),
                    child: Row(children: [
                      Icon(Icons.bubble_chart_rounded, size: 40, color: accent),
                      const SizedBox(width: 14),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        const Text('Floating App Bubble', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                        Text(_running ? 'Aktif — ketuk untuk menyembunyikan' : 'Ketuk untuk menampilkan',
                            style: const TextStyle(color: _ink.withValues(alpha: .68))),
                      ])),
                      Switch(value: _running, onChanged: (_) => _toggle()),
                    ]),
                  ),
                )),
                const SizedBox(height: 14),
                _fadeIn(3, GridView.count(
                  crossAxisCount: 2,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                  childAspectRatio: 1.7,
                  children: [for (final t in tiles) _Tile(label: t.$1, icon: t.$2, onTap: () => _openTool(t.$3))],
                )),
                const SizedBox(height: 14),
                _fadeIn(4, _glass(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('Pengaturan Bubble', style: TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 10),
                  const Text('Bentuk'),
                  const SizedBox(height: 6),
                  Wrap(spacing: 8, children: [
                    for (var i = 0; i < _shapes.length; i++)
                      ChoiceChip(
                        label: Text(_shapes[i]),
                        selected: _shape == i,
                        onSelected: (_) { setState(() => _shape = i); _push(); },
                      ),
                  ]),
                  const SizedBox(height: 8),
                  Text('Ukuran: ${_size.round()} dp'),
                  Slider(min: 48, max: 96, value: _size,
                      onChanged: (v) => setState(() => _size = v), onChangeEnd: (_) => _push()),
                  Text('Transparansi: ${(_alpha * 100).round()}%'),
                  Slider(min: .3, max: 1, value: _alpha,
                      onChanged: (v) => setState(() => _alpha = v), onChangeEnd: (_) => _push()),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('Sembunyikan bola', style: TextStyle(fontWeight: FontWeight.w800)),
                    subtitle: const Text('Bola menjadi sangat transparan; tekan lama di posisi bola untuk membuka menu dan menampilkannya lagi.'),
                    value: _stealth,
                    onChanged: (v) { setState(() => _stealth = v); _push(); },
                  ),
                  const Text('Warna'),
                  const SizedBox(height: 8),
                  Row(children: [
                    for (final c in _palette)
                      GestureDetector(
                        onTap: () { setState(() => _color = c); _push(); },
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          margin: const EdgeInsets.only(right: 10),
                          width: _color == c ? 38 : 30,
                          height: _color == c ? 38 : 30,
                          decoration: BoxDecoration(
                              color: Color(c),
                              shape: BoxShape.circle,
                              border: Border.all(color: Colors.white, width: _color == c ? 2 : 0)),
                        ),
                      ),
                    const Spacer(),
                    TextButton(
                        onPressed: () { setState(() { _color = _palette[0]; _shape = 0; }); _push(); },
                        child: const Text('Reset')),
                  ]),
                ]))),
              ]),
            ),
            Container(
              margin: const EdgeInsets.fromLTRB(16, 0, 16, 10),
              padding: const EdgeInsets.symmetric(vertical: 6),
              decoration: BoxDecoration(
                color: _yellow,
                borderRadius: BorderRadius.circular(4),
                border: Border.all(color: _ink, width: 2),
              ),
              child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
                IconButton(
                    icon: const Icon(Icons.home_rounded),
                    onPressed: () => _scroll.animateTo(0, duration: const Duration(milliseconds: 400), curve: Curves.easeOutCubic)),
                IconButton(
                    icon: Icon(Icons.power_settings_new_rounded, color: _running ? accent : null), onPressed: _toggle),
                IconButton(icon: const Icon(Icons.settings_rounded), onPressed: _openSettings),
                IconButton(
                    icon: const Icon(Icons.history_rounded),
                    onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const HistoryPage()))),
              ]),
            ),
          ]),
        ),
      ),
    );
  }
}

class _Tile extends StatefulWidget {
  final String label;
  final IconData icon;
  final VoidCallback onTap;
  const _Tile({required this.label, required this.icon, required this.onTap});
  @override
  State<_Tile> createState() => _TileState();
}

class _TileState extends State<_Tile> {
  bool _down = false;
  @override
  Widget build(BuildContext context) => GestureDetector(
        onTapDown: (_) => setState(() => _down = true),
        onTapCancel: () => setState(() => _down = false),
        onTapUp: (_) { setState(() => _down = false); widget.onTap(); },
        child: AnimatedScale(
          scale: _down ? .94 : 1,
          duration: const Duration(milliseconds: 120),
          child: Container(
            decoration: BoxDecoration(
              color: _down ? const Color(0xFFFF8FAB) : Colors.white,
              borderRadius: BorderRadius.circular(4),
              border: Border.all(color: _ink, width: 2),
              boxShadow: const [BoxShadow(color: _ink, offset: Offset(3, 3))],
            ),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(widget.icon, size: 30, color: _cyan),
              const SizedBox(height: 6),
              Text(widget.label, style: const TextStyle(fontWeight: FontWeight.w600)),
            ]),
          ),
        ),
      );
}

// ---------------------------------------------------------------- pengaturan backend & privasi
class _SettingsSheet extends StatefulWidget {
  final String url, anonKey;
  final bool historyOn;
  final void Function(String url, String key, bool history) onSaved;
  final Future<Map<String, dynamic>?> Function() onSynced;
  const _SettingsSheet({
    required this.url,
    required this.anonKey,
    required this.historyOn,
    required this.onSaved,
    required this.onSynced,
  });
  @override
  State<_SettingsSheet> createState() => _SettingsSheetState();
}

class _SettingsSheetState extends State<_SettingsSheet> {
  late final _u = TextEditingController(text: widget.url);
  late final _k = TextEditingController(text: widget.anonKey);
  late bool _h = widget.historyOn;
  bool _syncing = false;
  String? _syncMsg;

  @override
  void dispose() {
    _u.dispose();
    _k.dispose();
    super.dispose();
  }

  Future<void> _store() async {
    await _ch.invokeMethod('saveBackend', {'url': _u.text.trim(), 'key': _k.text.trim()});
    await _ch.invokeMethod('setHistoryOn', {'on': _h});
    widget.onSaved(_u.text.trim(), _k.text.trim(), _h);
  }

  Future<void> _save() async {
    await _store();
    if (mounted) Navigator.pop(context);
  }

  Future<void> _sync() async {
    setState(() { _syncing = true; _syncMsg = null; });
    String msg;
    try {
      await _store(); // pakai URL/key/riwayat yang sedang tampil di form
      msg = await _ch.invokeMethod<String>('syncNow') ?? 'Selesai.';
      await widget.onSynced();
    } on PlatformException catch (e) {
      msg = e.message ?? 'Sinkronisasi gagal.';
    }
    if (mounted) setState(() { _syncing = false; _syncMsg = msg; });
  }

  @override
  Widget build(BuildContext context) => Padding(
        padding: EdgeInsets.fromLTRB(20, 20, 20, 20 + MediaQuery.of(context).viewInsets.bottom),
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Backend Gemini (Supabase)', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
            const SizedBox(height: 4),
            Text('API key Gemini tidak disimpan di aplikasi — hanya di secret Edge Function. Anon key Supabase memang publik.',
                style: TextStyle(color: _ink.withValues(alpha: .7), fontSize: 12)),
            const SizedBox(height: 12),
            TextField(controller: _u, decoration: const InputDecoration(labelText: 'Supabase URL', hintText: 'https://xxxx.supabase.co')),
            TextField(controller: _k, decoration: const InputDecoration(labelText: 'Supabase anon key')),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Simpan riwayat jawaban'),
              subtitle: const Text('Screenshot mentah tidak pernah disimpan. Teks soal + jawaban ikut dikirim ke akun anonim Supabase-mu.'),
              value: _h,
              onChanged: (v) => setState(() => _h = v),
            ),
            OutlinedButton.icon(
              onPressed: _syncing ? null : _sync,
              icon: _syncing
                  ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.sync_rounded),
              label: const Text('Sinkronkan sekarang'),
            ),
            if (_syncMsg != null)
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Text(_syncMsg!, style: TextStyle(color: _ink.withValues(alpha: .7), fontSize: 12)),
              ),
            const SizedBox(height: 8),
            Row(children: [
              OutlinedButton.icon(
                onPressed: () => _ch.invokeMethod('killSwitch'),
                icon: const Icon(Icons.shield_rounded, color: Colors.redAccent),
                label: const Text('Stop capture'),
              ),
              const Spacer(),
              FilledButton(onPressed: _save, child: const Text('Simpan')),
            ]),
          ]),
        ),
      );
}

// ---------------------------------------------------------------- riwayat
class HistoryPage extends StatefulWidget {
  const HistoryPage({super.key});
  @override
  State<HistoryPage> createState() => _HistoryPageState();
}

class _HistoryPageState extends State<HistoryPage> {
  List<Map<String, dynamic>> _items = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final raw = await _ch.invokeMethod<String>('getHistory') ?? '[]';
    final l = (jsonDecode(raw) as List).cast<Map<String, dynamic>>();
    if (mounted) setState(() => _items = l);
  }

  Future<void> _fav(Map<String, dynamic> it) async {
    final v = !(it['fav'] as bool? ?? false);
    await _ch.invokeMethod('setFav', {'ts': it['ts'], 'fav': v});
    await _load();
  }

  Future<void> _clear() async {
    await _ch.invokeMethod('clearHistory');
    await _load();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const Text('Riwayat'),
          actions: [IconButton(icon: const Icon(Icons.delete_sweep_rounded), onPressed: _items.isEmpty ? null : _clear)],
        ),
        body: _items.isEmpty
            ? const Center(child: Text('Belum ada riwayat.\nAktifkan di Pengaturan → Simpan riwayat.', textAlign: TextAlign.center))
            : ListView.builder(
                itemCount: _items.length,
                itemBuilder: (_, i) {
                  final it = _items[i];
                  final fav = it['fav'] as bool? ?? false;
                  return ExpansionTile(
                    title: Text(it['q'] as String? ?? '', maxLines: 2, overflow: TextOverflow.ellipsis),
                    trailing: IconButton(
                      icon: Icon(fav ? Icons.star_rounded : Icons.star_border_rounded, color: fav ? Colors.amber : null),
                      onPressed: () => _fav(it),
                    ),
                    childrenPadding: const EdgeInsets.all(16),
                    expandedAlignment: Alignment.centerLeft,
                    children: [SelectableText(it['a'] as String? ?? '')],
                  );
                },
              ),
      );
}
