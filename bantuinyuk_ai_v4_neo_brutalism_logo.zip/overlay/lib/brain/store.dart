import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

/// Penyimpanan milik "otak" Dart: backend, sesi Supabase, riwayat, flag persetujuan.
/// Hanya isolate otak yang boleh memakai kelas ini; UI Flutter lewat Kotlin → otak,
/// sehingga tidak ada dua salinan state yang bisa berselisih.
class Store {
  Store(this._p);
  final SharedPreferences _p;

  static Future<Store> open() async => Store(await SharedPreferences.getInstance());

  static const maxHistory = 50;

  // ---- backend & flag
  String get backendUrl => (_p.getString('sb_url') ?? '').trim().replaceAll(RegExp(r'/+$'), '');
  String get anonKey => (_p.getString('sb_key') ?? '').trim();
  bool get historyOn => _p.getBool('history_on') ?? false;
  bool get accepted => _p.getBool('accepted') ?? false;
  bool get pendingClear => _p.getBool('pending_clear') ?? false;

  Future<void> setBackend(String url, String key) async {
    await _p.setString('sb_url', url);
    await _p.setString('sb_key', key);
  }

  Future<void> setHistoryOn(bool v) => _p.setBool('history_on', v);
  Future<void> setAccepted() => _p.setBool('accepted', true);
  Future<void> setPendingClear(bool v) => _p.setBool('pending_clear', v);

  // ---- sesi Supabase (anonim)
  String get accessToken => _p.getString('sb_access') ?? '';
  String get refreshToken => _p.getString('sb_refresh') ?? '';
  String get uid => _p.getString('sb_uid') ?? '';
  int get expiresAt => _p.getInt('sb_exp') ?? 0; // epoch detik

  Future<void> saveSession({required String access, required String refresh, required int exp, String? uid}) async {
    await _p.setString('sb_access', access);
    await _p.setString('sb_refresh', refresh);
    await _p.setInt('sb_exp', exp);
    if (uid != null) await _p.setString('sb_uid', uid);
  }

  Future<void> clearSession() async {
    for (final k in const ['sb_access', 'sb_refresh', 'sb_exp', 'sb_uid']) {
      await _p.remove(k);
    }
  }

  // ---- riwayat: [{ts, q, a, fav}] terbaru dulu, maks 50
  static int tsOf(Map<String, dynamic> o) => (o['ts'] as num?)?.toInt() ?? 0;

  List<Map<String, dynamic>> history() {
    try {
      final d = jsonDecode(_p.getString('history') ?? '[]');
      if (d is! List) return <Map<String, dynamic>>[];
      return d.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
    } catch (_) {
      return <Map<String, dynamic>>[];
    }
  }

  Future<void> _saveHistory(List<Map<String, dynamic>> l) => _p.setString('history', jsonEncode(l));

  Future<void> addHistory(String q, String a, {int? ts}) {
    final old = history();
    final out = <Map<String, dynamic>>[
      {'ts': ts ?? DateTime.now().millisecondsSinceEpoch, 'q': q, 'a': a, 'fav': false},
      ...old.take(maxHistory - 1),
    ];
    return _saveHistory(out);
  }

  Future<void> setFav(int ts, bool fav) {
    final l = history();
    for (final o in l) {
      if (tsOf(o) == ts) o['fav'] = fav;
    }
    return _saveHistory(l);
  }

  Future<void> clearHistory() => _p.remove('history');

  /// Tambahkan item server yang belum ada lokal (kunci: ts). Item lokal tidak ditimpa. Maks 50 terbaru.
  Future<int> mergeHistory(List<Map<String, dynamic>> remote) async {
    final all = history();
    final have = all.map(tsOf).toSet();
    var added = 0;
    for (final e in remote) {
      final ts = tsOf(e);
      if (ts != 0 && have.add(ts)) {
        all.add({'ts': ts, 'q': e['q'] ?? '', 'a': e['a'] ?? '', 'fav': e['fav'] == true});
        added++;
      }
    }
    all.sort((a, b) => tsOf(b).compareTo(tsOf(a)));
    await _saveHistory(all.take(maxHistory).toList());
    return added;
  }
}
