import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'supabase.dart';

class GeminiError implements Exception {
  GeminiError(this.message);
  final String message;
  @override
  String toString() => message;
}

/// Semua panggilan Gemini lewat Supabase Edge Function `gemini-proxy` — tidak ada API key di aplikasi.
class GeminiClient {
  GeminiClient(this.api);
  final SupabaseApi api;

  Future<String> ask(String mode, String text, Uint8List? image, {RequestHook? onRequest}) async {
    try {
      final body = <String, dynamic>{'mode': mode, 'text': text};
      if (image != null) {
        body['image_b64'] = base64Encode(image);
        body['mime'] = 'image/jpeg';
      }
      final r = await api.call('POST', '/functions/v1/gemini-proxy', jsonEncode(body), onRequest: onRequest);
      if (r.code == 429) throw GeminiError('Kuota habis atau terlalu banyak permintaan. Coba lagi nanti.');
      if (r.code == 401) {
        throw GeminiError('Sesi ditolak server. Coba lagi; bila tetap gagal, cek URL & anon key Supabase.');
      }
      if (!r.ok) {
        var msg = '';
        try {
          final j = jsonDecode(r.body);
          if (j is Map) msg = '${j['error'] ?? ''}';
        } catch (_) {}
        throw GeminiError('Server error (${r.code}). $msg'.trim());
      }
      var ans = '';
      try {
        final j = jsonDecode(r.body);
        if (j is Map) ans = '${j['answer'] ?? ''}'.trim();
      } catch (_) {}
      if (ans.isEmpty) throw GeminiError('Respons kosong dari Gemini. Coba lagi atau crop ulang.');
      return ans;
    } on GeminiError {
      rethrow;
    } on Failure catch (e) {
      throw GeminiError(e.message.isEmpty ? 'Gagal login ke backend.' : e.message);
    } on SocketException {
      throw GeminiError('Tidak ada koneksi internet.');
    } on TimeoutException {
      throw GeminiError('Timeout. Coba lagi.');
    } catch (e) {
      throw GeminiError('Gagal: $e');
    }
  }
}
