import 'dart:convert';

class ParsedQuestion {
  const ParsedQuestion(this.number, this.question, this.options);
  final String? number;
  final String question;
  final List<String> options;
}

/// Deteksi soal + pilihan jawaban dari teks OCR. Murni logika (tanpa Android).
class QuestionParser {
  static final _optRe = RegExp(r'^\s*\(?([A-Ea-e])[.)]\s*(.+)$');
  static final _numRe = RegExp(r'^\s*(\d{1,3})[.)]\s+(.+)$');
  static final _visualRe = RegExp(r'\b(gambar|grafik|diagram|tabel|peta|perhatikan)\b', caseSensitive: false);
  static final _alnumRe = RegExp(r'[\p{L}\p{Nd}]', unicode: true);

  static bool isReadable(String text, {int min = 12}) => _alnumRe.allMatches(text).length >= min;

  static bool needsImage(String text, List<ParsedQuestion> parsed) => _visualRe.hasMatch(text) || parsed.isEmpty;

  static List<ParsedQuestion> parse(String text) {
    final out = <ParsedQuestion>[];
    String? number;
    var q = StringBuffer();
    var opts = <String>[];
    var open = false;

    void flush() {
      if (open && (q.toString().trim().isNotEmpty || opts.isNotEmpty)) {
        out.add(ParsedQuestion(number, q.toString().trim(), List<String>.of(opts)));
      }
      q = StringBuffer();
      opts = <String>[];
      open = false;
      number = null;
    }

    for (final raw in const LineSplitter().convert(text)) {
      final line = raw.trim();
      if (line.isEmpty) continue;
      final n = _numRe.firstMatch(line);
      final o = _optRe.firstMatch(line);
      if (n != null) {
        flush();
        number = n.group(1);
        q.write(n.group(2));
        open = true;
      } else if (o != null && open) {
        opts.add('${o.group(1)!.toUpperCase()}. ${o.group(2)!.trim()}');
      } else if (open && opts.isEmpty) {
        q.write(' ');
        q.write(line);
      } else if (open) {
        opts[opts.length - 1] = '${opts.last} $line';
      }
    }
    flush();
    return out;
  }

  static String toPrompt(List<ParsedQuestion> parsed, String raw) {
    if (parsed.isEmpty) return raw.trim();
    return parsed.map((p) {
      final b = StringBuffer('Soal ${p.number ?? "?"}: ${p.question}');
      for (final o in p.options) {
        b.write('\n');
        b.write(o);
      }
      return b.toString();
    }).join('\n\n');
  }
}
