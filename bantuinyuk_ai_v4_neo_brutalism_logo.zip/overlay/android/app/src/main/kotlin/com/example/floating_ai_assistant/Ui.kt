package com.example.floating_ai_assistant

import android.animation.ValueAnimator
import android.content.Context
import android.content.res.Configuration
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.text.SpannableStringBuilder
import android.text.style.StyleSpan
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.max
import kotlin.math.min

fun overlayType(): Int =
    if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

@Suppress("DEPRECATION")
fun realSize(wm: WindowManager): Point =
    if (Build.VERSION.SDK_INT >= 30) {
        val b = wm.maximumWindowMetrics.bounds
        Point(b.width(), b.height())
    } else {
        val p = Point(); wm.defaultDisplay.getRealSize(p); p
    }

object Ui {
    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun night(c: Context) =
        (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    fun glass(c: Context, night: Boolean, radiusDp: Int = 4, cyan: Boolean = false): GradientDrawable =
        GradientDrawable().apply {
            cornerRadius = dp(c, minOf(radiusDp, 6)).toFloat()
            setColor(if (cyan) 0xFFFFE66D.toInt() else 0xFFFFF8E7.toInt())
            setStroke(dp(c, 2), 0xFF171717.toInt())
        }

    fun chip(c: Context, text: String, fg: Int, onClick: () -> Unit): TextView = TextView(c).apply {
        this.text = text; setTextColor(0xFF171717.toInt()); textSize = 14f; gravity = android.view.Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(c, 12), dp(c, 10), dp(c, 12), dp(c, 10))
        background = GradientDrawable().apply { cornerRadius = dp(c, 3).toFloat(); setColor(0xFFFFFFFF.toInt()); setStroke(dp(c, 2), 0xFF171717.toInt()) }
        elevation = dp(c, 3).toFloat()
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(c, 8) }
    }

    fun row(c: Context, vararg v: View): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.HORIZONTAL
        v.forEach { addView(it, LinearLayout.LayoutParams(0, -2, 1f).apply { topMargin = dp(c, 8); marginStart = dp(c, 3); marginEnd = dp(c, 3) }) }
    }

    /** Markdown ringan: **tebal**, *miring*, daftar "- ", dan judul "#". */
    fun md(src: String): CharSequence {
        val sb = SpannableStringBuilder()
        val bullet = Regex("""^\s*[*-]\s+""")
        for (raw in src.lines()) {
            var line = raw
            val bm = bullet.find(line)
            if (bm != null) line = "• " + line.substring(bm.range.last + 1)
            val header = line.startsWith("#")
            if (header) line = line.trimStart('#').trim()
            val lineStart = sb.length
            var i = 0
            while (i < line.length) {
                if (line.startsWith("**", i)) {
                    val e = line.indexOf("**", i + 2)
                    if (e > 0) { val s = sb.length; sb.append(line, i + 2, e); sb.setSpan(StyleSpan(Typeface.BOLD), s, sb.length, 0); i = e + 2; continue }
                }
                if (line[i] == '*') {
                    val e = line.indexOf('*', i + 1)
                    if (e > i + 1) { val s = sb.length; sb.append(line, i + 1, e); sb.setSpan(StyleSpan(Typeface.ITALIC), s, sb.length, 0); i = e + 1; continue }
                }
                sb.append(line[i]); i++
            }
            if (header) sb.setSpan(StyleSpan(Typeface.BOLD), lineStart, sb.length, 0)
            sb.append('\n')
        }
        if (sb.isNotEmpty()) sb.delete(sb.length - 1, sb.length)
        return sb
    }
}

/** Bubble kaca. shape: 0 lingkaran (default), 1 kotak, 2 bulat (rounded), 3 segitiga. */
class BubbleView(ctx: Context) : View(ctx) {
    private var tint = 0xFF3B82F6.toInt()
    private var a = 0.85f
    private var g = 0f
    private var shape = 0
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val hi = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = 0xB3FFFFFF.toInt() }
    private val icon = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val sparkle = Path()
    private val body = Path()

    init { setLayerType(LAYER_TYPE_SOFTWARE, null) }

    fun style(color: Int, alpha: Float, shape: Int) { tint = color; a = alpha; this.shape = shape; invalidate() }

    fun glow(on: Boolean) {
        ValueAnimator.ofFloat(g, if (on) 1f else 0f).apply {
            duration = 140
            addUpdateListener { g = it.animatedValue as Float; invalidate() }
        }.start()
    }

    override fun onDraw(c: Canvas) {
        val d = resources.displayMetrics.density
        val cx = width / 2f; val cy = height / 2f
        val r = min(width, height) / 2f - 9 * d
        val tr = Color.red(tint); val tg = Color.green(tint); val tb = Color.blue(tint)
        fill.setShadowLayer(3 * d + 5 * d * g, 0f, 1.5f * d, Color.argb(((70 + 110 * g) * a).toInt().coerceIn(0, 255), tr, tg, tb))
        fill.shader = RadialGradient(
            cx - r * 0.3f, cy - r * 0.4f, r * 1.6f,
            intArrayOf(
                Color.argb((255 * a * 0.55f).toInt(), 255, 255, 255),
                Color.argb((255 * a).toInt(), tr, tg, tb),
                Color.argb((255 * a * 0.8f).toInt(), tr / 2, tg / 2, tb / 2)
            ), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        body.rewind()
        val box = RectF(cx - r, cy - r, cx + r, cy + r)
        when (shape) {
            1 -> body.addRoundRect(box, r * 0.18f, r * 0.18f, Path.Direction.CW)
            2 -> body.addRoundRect(box, r * 0.55f, r * 0.55f, Path.Direction.CW)
            3 -> { body.moveTo(cx, cy - r); body.lineTo(cx + r * 0.95f, cy + r * 0.8f); body.lineTo(cx - r * 0.95f, cy + r * 0.8f); body.close() }
            else -> body.addCircle(cx, cy, r, Path.Direction.CW)
        }
        c.drawPath(body, fill)
        ring.strokeWidth = 1.2f * d
        ring.color = Color.argb((220 * a).toInt().coerceIn(0, 255), 23, 23, 23)
        c.drawPath(body, ring)
        if (shape == 0) {
            hi.strokeWidth = 2f * d
            hi.color = Color.argb((180 * a).toInt().coerceIn(0, 255), 23, 23, 23)
            c.drawArc(RectF(cx - r * .78f, cy - r * .78f, cx + r * .78f, cy + r * .78f), 205f, 80f, false, hi)
        }
        val s = r * 0.42f
        val sy = if (shape == 3) cy + r * 0.15f else cy
        sparkle.rewind()
        sparkle.moveTo(cx, sy - s); sparkle.quadTo(cx, sy, cx + s, sy)
        sparkle.quadTo(cx, sy, cx, sy + s); sparkle.quadTo(cx, sy, cx - s, sy)
        sparkle.quadTo(cx, sy, cx, sy - s); sparkle.close()
        icon.alpha = (255 * a).toInt().coerceIn(0, 255)
        c.drawPath(sparkle, icon)
    }
}

/** Layar beku + kotak seleksi dengan handle, tombol ✕ / ↺ / ✓ dan garis tepi aksen. */
class CropView(
    ctx: Context, private val bmp: Bitmap, private val initial: Rect?, accent: Int,
    private val onDone: (Rect?) -> Unit
) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val sel = RectF()
    private var ready = false
    private var mode = 0          // -1 tombol, 1 geser, 2..5 sudut TL/TR/BL/BR, 6 buat baru
    private var pressed = -1
    private var lx = 0f; private var ly = 0f; private var ax = 0f; private var ay = 0f
    private val pBmp = Paint(Paint.FILTER_BITMAP_FLAG)
    private val pDim = Paint().apply { color = 0x99000000.toInt() }
    private val pBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = accent; strokeWidth = 2 * d }
    private val pFrame = Paint().apply { style = Paint.Style.STROKE; color = accent; strokeWidth = 6 * d }
    private val pFill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pTxt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER; textSize = 18 * d }
    private val btnColors = intArrayOf(0xFFEF4444.toInt(), 0xFF64748B.toInt(), 0xFF22C55E.toInt())
    private val btnLabels = arrayOf("✕", "↺", "✓")

    private fun resetSel() {
        if (initial != null) {
            val sx = width / bmp.width.toFloat(); val sy = height / bmp.height.toFloat()
            sel.set(initial.left * sx - 8 * d, initial.top * sy - 8 * d, initial.right * sx + 8 * d, initial.bottom * sy + 8 * d)
        } else sel.set(width * .12f, height * .35f, width * .88f, height * .55f)
        clampSel()
    }

    private fun clampSel() {
        val m = 48 * d
        sel.left = sel.left.coerceIn(0f, width - m); sel.top = sel.top.coerceIn(0f, height - m)
        sel.right = sel.right.coerceIn(sel.left + m, width.toFloat()); sel.bottom = sel.bottom.coerceIn(sel.top + m, height.toFloat())
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        if (!ready && w > 0 && h > 0) { resetSel(); ready = true }
    }

    private fun btnCenter(i: Int): PointF {
        var by = sel.bottom + 36 * d
        if (by > height - 30 * d) by = sel.top - 36 * d
        return PointF(sel.centerX() + (i - 1) * 64 * d, by)
    }

    private fun hitBtn(x: Float, y: Float): Int {
        for (i in 0..2) { val p = btnCenter(i); if (Math.hypot((x - p.x).toDouble(), (y - p.y).toDouble()) < 28 * d) return i }
        return -1
    }

    private fun hit(x: Float, y: Float): Int {
        val r = 30 * d
        fun near(px: Float, py: Float) = Math.hypot((x - px).toDouble(), (y - py).toDouble()) < r
        return when {
            near(sel.left, sel.top) -> 2
            near(sel.right, sel.top) -> 3
            near(sel.left, sel.bottom) -> 4
            near(sel.right, sel.bottom) -> 5
            sel.contains(x, y) -> 1
            else -> 6
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lx = e.x; ly = e.y
                val b = hitBtn(e.x, e.y)
                if (b >= 0) { pressed = b; mode = -1 } else {
                    mode = hit(e.x, e.y)
                    if (mode == 6) { ax = e.x; ay = e.y; sel.set(ax, ay, ax, ay) }
                }
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - lx; val dy = e.y - ly
                when (mode) {
                    1 -> {
                        val w = sel.width(); val h = sel.height()
                        val nl = (sel.left + dx).coerceIn(0f, width - w); val nt = (sel.top + dy).coerceIn(0f, height - h)
                        sel.set(nl, nt, nl + w, nt + h)
                    }
                    2 -> { sel.left += dx; sel.top += dy; clampSel() }
                    3 -> { sel.right += dx; sel.top += dy; clampSel() }
                    4 -> { sel.left += dx; sel.bottom += dy; clampSel() }
                    5 -> { sel.right += dx; sel.bottom += dy; clampSel() }
                    6 -> { sel.set(min(ax, e.x), min(ay, e.y), max(ax, e.x), max(ay, e.y)); clampSel() }
                }
                lx = e.x; ly = e.y
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                if (mode == -1 && hitBtn(e.x, e.y) == pressed) when (pressed) {
                    0 -> onDone(null)
                    1 -> { resetSel(); invalidate() }
                    2 -> {
                        val a = CropMath.toBitmapRect(sel.left, sel.top, sel.right, sel.bottom, width, height, bmp.width, bmp.height)
                        onDone(Rect(a[0], a[1], a[2], a[3]))
                    }
                }
                mode = 0
            }
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        c.drawBitmap(bmp, null, RectF(0f, 0f, w, h), pBmp)
        c.drawRect(0f, 0f, w, sel.top, pDim); c.drawRect(0f, sel.bottom, w, h, pDim)
        c.drawRect(0f, sel.top, sel.left, sel.bottom, pDim); c.drawRect(sel.right, sel.top, w, sel.bottom, pDim)
        c.drawRect(sel, pBorder)
        c.drawRect(0f, 0f, w, h, pFrame)
        pFill.color = Color.WHITE
        for (p in listOf(PointF(sel.left, sel.top), PointF(sel.right, sel.top), PointF(sel.left, sel.bottom), PointF(sel.right, sel.bottom)))
            c.drawCircle(p.x, p.y, 7 * d, pFill)
        c.drawText("Atur kotak lalu ketuk ✓", w / 2, 64 * d, pTxt)
        for (i in 0..2) {
            val p = btnCenter(i)
            pFill.color = btnColors[i]
            c.drawCircle(p.x, p.y, 24 * d, pFill)
            c.drawText(btnLabels[i], p.x, p.y + 6 * d, pTxt)
        }
    }
}

/** Overlay coretan/anotasi. */
class DrawView(ctx: Context) : View(ctx) {
    private class Stroke(val path: Path, val paint: Paint)
    private val strokes = mutableListOf<Stroke>()
    private var cur: Stroke? = null
    var color = 0xFFEF4444.toInt()
    var widthPx = 6f * resources.displayMetrics.density

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val p = Path().apply { moveTo(e.x, e.y); lineTo(e.x + 0.1f, e.y + 0.1f) }
                val s = Stroke(p, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
                    color = this@DrawView.color; strokeWidth = widthPx
                })
                strokes.add(s); cur = s
            }
            MotionEvent.ACTION_MOVE -> cur?.path?.lineTo(e.x, e.y)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> cur = null
        }
        invalidate()
        return true
    }

    fun undo() { if (strokes.isNotEmpty()) strokes.removeAt(strokes.lastIndex); invalidate() }
    fun clear() { strokes.clear(); invalidate() }
    override fun onDraw(c: Canvas) { for (s in strokes) c.drawPath(s.path, s.paint) }
}
