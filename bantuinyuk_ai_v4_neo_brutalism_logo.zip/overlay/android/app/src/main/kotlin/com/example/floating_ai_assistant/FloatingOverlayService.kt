package com.example.floating_ai_assistant

import android.animation.ValueAnimator
import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import java.util.Locale
import kotlin.math.abs

class FloatingOverlayService : Service() {
    companion object {
        const val ACTION_STOP = "stop"
        const val ACTION_KILL = "kill"
        @Volatile var running = false
    }

    lateinit var wm: WindowManager
    lateinit var windows: OverlayWindowManager
    lateinit var capture: ScreenCaptureManager
    private lateinit var tools: Tools
    private lateinit var lp: WindowManager.LayoutParams
    private val main = Handler(Looper.getMainLooper())

    private var bubble: BubbleView? = null
    private var panel: View? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var menu: View? = null
    private var cropView: View? = null
    var drawView: View? = null
    private var statusView: TextView? = null
    private var resultView: TextView? = null
    private var boxView: View? = null
    private var toggleView: TextView? = null

    private var lastClosedAt = 0L
    private var expanded = false
    private var status = "Siap"
    private var answerText = ""
    private var lastPrompt = ""
    private var lastOcr: Text? = null
    @Volatile private var autoAnswerRunning = false
    private var currentCall: GeminiClient.Call? = null
    private var pendingAfterGrant: (() -> Unit)? = null
    private var speechCb: ((String) -> Unit)? = null
    private var pickCb: ((Bitmap) -> Unit)? = null
    private var tts: TextToSpeech? = null

    val prefs: SharedPreferences get() = Store.p(this)
    val d: Float get() = resources.displayMetrics.density
    fun px(v: Int) = (v * d).toInt()
    private val sizePx get() = px(prefs.getInt("size", 64))
    private fun screen() = realSize(wm)
    private val night get() = Ui.night(this)
    private val fg get() = 0xFF171717.toInt()
    fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { handleResult(i) }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        running = true
        Brain.warm(applicationContext)
        windows = OverlayWindowManager(this)
        capture = ScreenCaptureManager(this) { setStatus("Capture berhenti"); startFg(false) }
        tools = Tools(this)
        val f = IntentFilter(TrampolineActivity.ACTION_RESULT)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED) else registerReceiver(receiver, f)
        startFg(false)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopSelf(); return START_NOT_STICKY }
            ACTION_KILL -> { killSwitch(); return START_STICKY }
        }
        if (bubble == null) addBubble() else applyStyle()
        when (intent?.getStringExtra("tool")) {
            "search" -> tools.openSearch()
            "gemini" -> tools.openGemini()
            "translate" -> tools.openTranslate()
            "gallery" -> tools.openGallery()
            "draw" -> tools.openDraw()
        }
        return START_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        capture.onResize()
        if (bubble != null) {
            closeTransient()
            val sc = screen()
            lp.x = if (prefs.getBoolean("right", true)) sc.x - sizePx else 0
            lp.y = lp.y.coerceIn(px(24), (sc.y - sizePx - px(48)).coerceAtLeast(px(24)))
            runCatching { wm.updateViewLayout(bubble, lp) }
        }
    }

    override fun onDestroy() {
        running = false
        autoAnswerRunning = false
        currentCall?.cancel()
        runCatching { unregisterReceiver(receiver) }
        capture.release()
        windows.closeAll()
        closeCrop(); closeDraw()
        panel?.let { runCatching { wm.removeView(it) } }
        menu?.let { runCatching { wm.removeView(it) } }
        bubble?.let { runCatching { wm.removeView(it) } }
        panel = null; menu = null; bubble = null
        tts?.shutdown()
        cleanTemp()
        super.onDestroy()
    }

    // ---------- foreground ----------
    private fun startFg(withProjection: Boolean) {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26)
            nm.createNotificationChannel(NotificationChannel("bubble", "bantuinYuk AI", NotificationManager.IMPORTANCE_LOW))
        fun pi(code: Int, action: String) = PendingIntent.getService(
            this, code, Intent(this, FloatingOverlayService::class.java).setAction(action), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(this, "bubble")
            .setSmallIcon(applicationInfo.icon)
            .setContentTitle("bantuinYuk AI aktif")
            .setContentText(if (withProjection) "Sesi capture layar aktif" else "Bubble aktif")
            .addAction(0, "Stop capture", pi(1, ACTION_KILL))
            .addAction(0, "Matikan", pi(2, ACTION_STOP))
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 34) {
            val type = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE or
                (if (withProjection) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION else 0)
            ServiceCompat.startForeground(this, 1, n, type)
        } else startForeground(1, n)
    }

    // ---------- hasil dari TrampolineActivity ----------
    private fun handleResult(i: Intent) {
        val ok = i.getBooleanExtra("ok", false)
        when (i.getIntExtra("req", 0)) {
            1 -> {
                val cb = pendingAfterGrant; pendingAfterGrant = null
                @Suppress("DEPRECATION") val data = i.getParcelableExtra<Intent>("data")
                if (ok && data != null) {
                    startFg(true)
                    runCatching { capture.start(i.getIntExtra("code", Activity.RESULT_OK), data) }
                        .onFailure { toast("Gagal memulai capture: ${it.message}"); return }
                    cb?.invoke()
                } else { toast("Izin screen capture ditolak."); setStatus("Izin ditolak") }
            }
            2 -> { val t = i.getStringExtra("text"); if (ok && !t.isNullOrBlank()) speechCb?.invoke(t); speechCb = null }
            3 -> {
                val path = i.getStringExtra("path")
                if (ok && path != null) {
                    val bmp = BitmapFactory.decodeFile(path); File(path).delete()
                    if (bmp != null) pickCb?.invoke(bmp)
                }
                pickCb = null
            }
        }
    }

    private fun launchTramp(kind: String) {
        try {
            startActivity(Intent(this, TrampolineActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra(TrampolineActivity.KIND, kind))
        } catch (e: Exception) { toast("Tidak bisa membuka layar izin: ${e.message}") }
    }
    fun requestSpeech(cb: (String) -> Unit) { speechCb = cb; launchTramp("speech") }
    fun requestPick(cb: (Bitmap) -> Unit) { pickCb = cb; launchTramp("pick") }
    private fun ensureCapture(next: () -> Unit) {
        if (capture.active) next() else { pendingAfterGrant = next; launchTramp("capture") }
    }

    // ---------- bubble ----------
    /** Ubah gaya bubble + tandai waktu perubahan (dipakai sinkronisasi). */
    fun editStyle(block: SharedPreferences.Editor.() -> Unit) {
        prefs.edit().apply(block).putLong("settings_ts", System.currentTimeMillis()).apply()
        applyStyle()
    }

    fun applyStyle() {
        val b = bubble ?: return
        val alpha = if (prefs.getBoolean("stealth", false)) 0.035f else prefs.getFloat("alpha", 0.85f)
        b.style(prefs.getInt("color", 0xFF3B82F6.toInt()), alpha, prefs.getInt("shape", 0))
        lp.width = sizePx; lp.height = sizePx
        runCatching { wm.updateViewLayout(b, lp) }
    }

    private fun addBubble() {
        val v = BubbleView(this)
        bubble = v
        val alpha = if (prefs.getBoolean("stealth", false)) 0.035f else prefs.getFloat("alpha", 0.85f)
        v.style(prefs.getInt("color", 0xFF3B82F6.toInt()), alpha, prefs.getInt("shape", 0))
        lp = WindowManager.LayoutParams(
            sizePx, sizePx, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = if (prefs.getBoolean("right", true)) screen().x - sizePx else 0
            y = prefs.getInt("y", px(240))
        }
        var sx = 0; var sy = 0; var dx = 0f; var dy = 0f; var moved = false; var longFired = false
        val longPress = Runnable { if (!moved) { longFired = true; showToolsMenu() } }
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = lp.x; sy = lp.y; dx = e.rawX; dy = e.rawY; moved = false; longFired = false
                    view.animate().scaleX(0.9f).scaleY(0.9f).setDuration(90).setInterpolator(null).start()
                    v.glow(true)
                    main.postDelayed(longPress, 450)
                }
                MotionEvent.ACTION_MOVE -> {
                    val ox = e.rawX - dx; val oy = e.rawY - dy
                    if (!moved && (abs(ox) > px(6) || abs(oy) > px(6))) { moved = true; main.removeCallbacks(longPress); closeTransient() }
                    if (moved) { lp.x = (sx + ox).toInt(); lp.y = (sy + oy).toInt(); wm.updateViewLayout(view, lp) }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    main.removeCallbacks(longPress)
                    view.animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(OvershootInterpolator(3f)).start()
                    v.glow(false)
                    if (moved) snap() else if (!longFired && e.actionMasked == MotionEvent.ACTION_UP) togglePanel()
                }
            }
            true
        }
        wm.addView(v, lp)
    }

    private fun snap() {
        val sc = screen()
        val right = lp.x + sizePx / 2 > sc.x / 2
        val tx = if (right) sc.x - sizePx else 0
        lp.y = lp.y.coerceIn(px(24), (sc.y - sizePx - px(48)).coerceAtLeast(px(24)))
        ValueAnimator.ofInt(lp.x, tx).apply {
            duration = 260; interpolator = DecelerateInterpolator()
            addUpdateListener {
                lp.x = it.animatedValue as Int
                bubble?.let { b -> if (b.isAttachedToWindow) wm.updateViewLayout(b, lp) }
            }
        }.start()
        prefs.edit().putBoolean("right", right).putInt("y", lp.y).apply()
    }

    private fun togglePanel() {
        if (panel != null) closePanel()
        else if (System.currentTimeMillis() - lastClosedAt > 250) openPanel()
    }

    fun closeTransient() { closePanel(); closeMenu() }

    // ---------- panel ----------
    private fun setStatus(s: String) { status = s; statusView?.text = "● $s" }

    private fun relayoutPanel() { panelLp?.let { p -> panel?.let { runCatching { wm.updateViewLayout(it, p) } } } }

    private fun refreshPanel() {
        resultView?.text = if (answerText.isEmpty()) "Belum ada jawaban." else Ui.md(answerText)
        statusView?.text = "● $status"
    }

    fun showAnswer(text: String) {
        answerText = text; expanded = true
        if (panel == null) openPanel() else {
            boxView?.visibility = View.VISIBLE; toggleView?.text = "⌃"
            refreshPanel(); relayoutPanel()
        }
    }

    private fun fail(msg: String) { setStatus("Gagal"); showAnswer(msg) }

    private fun openPanel() {
        closeTransient()
        val c = fg
        val sc = screen()
        val w = px(304).coerceAtMost(sc.x - px(24)).coerceAtLeast(px(240))
        val maxPanelHeight = (sc.y - px(56)).coerceAtMost(px(620)).coerceAtLeast(px(280))
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(12), px(12), px(12), px(12))
            background = Ui.glass(this@FloatingOverlayService, night)
            elevation = px(12).toFloat()
        }

        val head = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(px(2), px(2), px(2), px(8))
        }
        head.addView(TextView(this).apply {
            text = "BANTUINYUK AI"
            setTextColor(c)
            textSize = 15f
            typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
            letterSpacing = 0.04f
        }, LinearLayout.LayoutParams(0, -2, 1f))
        val st = TextView(this).apply {
            text = "● $status"
            setTextColor(0xFF16803C.toInt())
            textSize = 11f
            maxLines = 1
            setPadding(0, 0, px(8), 0)
        }
        statusView = st
        head.addView(st)
        val toggle = TextView(this).apply {
            text = if (expanded) "−" else "+"
            setTextColor(c)
            textSize = 20f
            gravity = Gravity.CENTER
            setPadding(px(7), 0, px(7), 0)
            background = Ui.glass(this@FloatingOverlayService, night, 3, true)
        }
        toggleView = toggle
        head.addView(toggle, LinearLayout.LayoutParams(px(34), px(34)))
        head.addView(TextView(this).apply {
            text = "×"
            setTextColor(c)
            textSize = 22f
            gravity = Gravity.CENTER
            setPadding(px(7), 0, px(2), 0)
            setOnClickListener { closePanel() }
        }, LinearLayout.LayoutParams(px(34), px(34)))
        root.addView(head)

        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(TextView(this).apply {
            text = "AKSI CEPAT"
            setTextColor(0xFF171717.toInt())
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.12f
            setPadding(px(2), px(4), 0, 0)
        })
        content.addView(Ui.row(this,
            Ui.chip(this, "Kerjakan Soal", c) { solve() },
            Ui.chip(this, "Crop Area", c) { startCrop { chooseTarget(it) } }
        ))
        content.addView(Ui.row(this,
            Ui.chip(this, if (autoAnswerRunning) "■ Hentikan" else "▶ Auto Jawab", c) { toggleAutoAnswer() },
            Ui.chip(this, "Izin Otomatis", c) { openAccessibilitySettings() }
        ))
        content.addView(Ui.row(this,
            Ui.chip(this, "Alat Lainnya", c) { showToolsMenu() },
            Ui.chip(this, "Stop Capture", 0xFFFCA5A5.toInt()) { killSwitch() }
        ))

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = if (expanded) View.VISIBLE else View.GONE
            setPadding(0, px(10), 0, 0)
        }
        box.addView(View(this).apply {
            setBackgroundColor(0xFF171717.toInt())
        }, LinearLayout.LayoutParams(-1, px(2)))
        box.addView(TextView(this).apply {
            text = "HASIL"
            setTextColor(0xFF171717.toInt())
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.12f
            setPadding(px(2), px(10), 0, px(2))
        })
        val res = TextView(this).apply {
            setTextColor(c)
            textSize = 13f
            setTextIsSelectable(true)
            text = if (answerText.isEmpty()) "Belum ada jawaban." else Ui.md(answerText)
            setPadding(px(10), px(10), px(10), px(10))
            background = Ui.glass(this@FloatingOverlayService, night, 3)
            setLineSpacing(px(2).toFloat(), 1f)
        }
        resultView = res
        boxView = box
        box.addView(ScrollView(this).apply {
            isFillViewport = false
            addView(res, ScrollView.LayoutParams(-1, -2))
        }, LinearLayout.LayoutParams(-1, px(160)))
        box.addView(Ui.row(this,
            Ui.chip(this, "Jelaskan", c) { explain() },
            Ui.chip(this, "Scan Ulang", c) { solve() }
        ))
        box.addView(Ui.row(this,
            Ui.chip(this, "Salin", c) { copyText(answerText) },
            Ui.chip(this, "Bacakan", c) { speak(answerText) }
        ))
        content.addView(box)

        val scroll = object : ScrollView(this) {
            override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
                val capped = View.MeasureSpec.makeMeasureSpec((maxPanelHeight - px(80)).coerceAtLeast(px(160)), View.MeasureSpec.AT_MOST)
                super.onMeasure(widthMeasureSpec, capped)
            }
        }.apply {
            isFillViewport = false
            clipToPadding = false
            setPadding(0, 0, px(2), 0)
            addView(content, ScrollView.LayoutParams(-1, -2))
        }
        root.addView(scroll, LinearLayout.LayoutParams(-1, -2))

        toggle.setOnClickListener {
            expanded = !expanded
            toggle.text = if (expanded) "−" else "+"
            box.visibility = if (expanded) View.VISIBLE else View.GONE
            relayoutPanel()
        }

        val right = prefs.getBoolean("right", true)
        val candidateX = if (right) lp.x - w - px(8) else lp.x + sizePx + px(8)
        val candidateY = lp.y.coerceIn(px(24), (sc.y - maxPanelHeight - px(16)).coerceAtLeast(px(24)))
        val p = WindowManager.LayoutParams(
            w, -2, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = candidateX.coerceIn(px(8), (sc.x - w - px(8)).coerceAtLeast(px(8)))
            y = candidateY
            if (Build.VERSION.SDK_INT >= 31 && wm.isCrossWindowBlurEnabled) {
                flags = flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
                blurBehindRadius = 40
            }
        }
        root.setOnTouchListener { _, e -> if (e.action == MotionEvent.ACTION_OUTSIDE) closePanel(); false }
        panel = root
        panelLp = p
        root.alpha = 0f
        root.scaleX = 0.96f
        root.scaleY = 0.96f
        root.pivotX = if (right) w.toFloat() else 0f
        root.pivotY = 0f
        wm.addView(root, p)
        root.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(180).setInterpolator(DecelerateInterpolator()).start()
    }

    private fun closePanel() {
        val p = panel ?: return
        panel = null; panelLp = null; statusView = null; resultView = null; boxView = null; toggleView = null
        lastClosedAt = System.currentTimeMillis()
        p.animate().alpha(0f).scaleX(0.92f).scaleY(0.92f).setDuration(130).withEndAction { runCatching { wm.removeView(p) } }.start()
    }

    // ---------- menu (Alat Cepat / pilihan target) ----------
    fun showToolsMenu() {
        showMenu(listOf(
            "Asisten" to { openPanel() },
            "Pencarian" to { tools.openSearch() },
            "Tanya Gemini" to { tools.openGemini() },
            "Terjemahan" to { tools.openTranslate() },
            "Gambar (Draw)" to { tools.openDraw() },
            "Galeri" to { tools.openGallery() },
            (if (prefs.getBoolean("stealth", false)) "Tampilkan bola normal" else "Sembunyikan bola (transparan)") to {
                editStyle { putBoolean("stealth", !prefs.getBoolean("stealth", false)) }
            },
            "Pengaturan Bubble" to { tools.openSettings() },
            "⏻ Stop capture" to { killSwitch() },
            "Matikan bubble" to { stopSelf() }
        ))
    }

    private fun showMenu(items: List<Pair<String, () -> Unit>>) {
        closeTransient()
        val c = fg
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(8), px(8), px(8), px(8))
            background = Ui.glass(this@FloatingOverlayService, night, 20, true)
            elevation = px(12).toFloat()
        }
        for ((label, act) in items) {
            root.addView(TextView(this).apply {
                text = label; setTextColor(c); textSize = 14f
                setPadding(px(14), px(10), px(14), px(10))
                setOnClickListener { closeMenu(); act() }
            })
        }
        val w = px(210)
        val estH = px(16 + items.size * 42)
        val right = prefs.getBoolean("right", true)
        val sc = screen()
        val p = WindowManager.LayoutParams(
            w, -2, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = if (right) lp.x - w - px(8) else lp.x + sizePx + px(8)
            y = lp.y.coerceIn(px(24), (sc.y - estH - px(24)).coerceAtLeast(px(24)))
        }
        root.setOnTouchListener { _, e -> if (e.action == MotionEvent.ACTION_OUTSIDE) closeMenu(); false }
        menu = root
        root.alpha = 0f; root.translationX = if (right) px(16).toFloat() else -px(16).toFloat()
        wm.addView(root, p)
        root.animate().alpha(1f).translationX(0f).setDuration(220).setInterpolator(DecelerateInterpolator()).start()
    }

    private fun closeMenu() {
        val m = menu ?: return
        menu = null; lastClosedAt = System.currentTimeMillis()
        m.animate().alpha(0f).setDuration(110).withEndAction { runCatching { wm.removeView(m) } }.start()
    }

    // ---------- capture, OCR, Gemini ----------
    private fun grab(cb: (Bitmap?) -> Unit) {
        bubble?.visibility = View.INVISIBLE; windows.setVisible(false); drawView?.visibility = View.INVISIBLE
        closeTransient()
        main.postDelayed({
            capture.capture { bmp ->
                bubble?.visibility = View.VISIBLE; windows.setVisible(true); drawView?.visibility = View.VISIBLE
                cb(bmp)
            }
        }, 200)
    }

    private fun ocr(bmp: Bitmap, cb: (Text?) -> Unit) {
        recognizer.process(InputImage.fromBitmap(bmp, 0)).addOnSuccessListener { cb(it) }.addOnFailureListener { cb(null) }
    }

    fun solve() {
        setStatus("Membaca layar…")
        ensureCapture {
            grab { bmp ->
                when {
                    bmp == null -> fail("Gagal mengambil layar. Coba Scan Ulang.")
                    ScreenCaptureManager.isBlank(bmp) -> fail("Layar tampak kosong/hitam. Aplikasi target mungkin memblokir screen capture (FLAG_SECURE). Itu batasan Android dan tidak diakali aplikasi ini.")
                    else -> ocr(bmp) { t ->
                        val text = t?.text ?: ""
                        lastOcr = t
                        // Deteksi soal dilakukan otak Dart (lib/brain/parser.dart).
                        Brain.call(this, "prepare", mapOf("text" to text)) { r ->
                            val p = r.getOrNull() as? Map<*, *>
                            when {
                                p == null -> fail("Mesin AI belum siap. Coba lagi sebentar lagi.")
                                p["readable"] != true -> fail("Soal tidak terbaca dengan baik. Coba Crop Area atau Scan Ulang.")
                                else -> {
                                    lastPrompt = (p["prompt"] as? String) ?: text
                                    askGemini("solve", lastPrompt, if (p["needsImage"] == true) bmp else null)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private fun openAccessibilitySettings() {
        try {
            startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            toast("Aktifkan layanan bantuinYuk AI di Aksesibilitas, lalu kembali ke bubble.")
        } catch (e: Exception) { toast("Pengaturan aksesibilitas tidak bisa dibuka: ${e.message}") }
    }

    private fun toggleAutoAnswer() {
        if (autoAnswerRunning) {
            autoAnswerRunning = false
            setStatus("Otomatis dihentikan")
            toast("Auto jawab dihentikan")
            return
        }
        if (!AutoAnswerAccessibilityService.connected) {
            openAccessibilitySettings()
            return
        }
        autoAnswerRunning = true
        setStatus("Auto jawab aktif")
        toast("Auto jawab aktif. Tekan Hentikan otomatis untuk berhenti.")
        solve()
    }

    private fun answerLetter(answer: String): String? {
        val match = Regex("(?im)^\\s*Jawaban\\s*:\\s*([A-E])\\b").find(answer)
            ?: Regex("(?im)^\\s*([A-E])[.)]\\s*").find(answer)
        return match?.groupValues?.getOrNull(1)?.uppercase(Locale.ROOT)
    }

    private fun findOptionLine(t: Text?, letter: String): Text.Line? {
        val pattern = Regex("(?i)^\\s*" + Regex.escape(letter) + "\\s*[.) :\\-]\\s*\\S")
        return t?.textBlocks?.flatMap { it.lines }?.firstOrNull { pattern.containsMatchIn(it.text) && it.boundingBox != null }
    }

    private fun findNextLine(t: Text?): Text.Line? {
        val pattern = Regex("(?i)\\b(lanjutkan|berikutnya|selanjutnya|next|continue|submit|kirim jawaban|periksa jawaban|selesai)\\b")
        return t?.textBlocks?.flatMap { it.lines }?.firstOrNull { pattern.containsMatchIn(it.text) && it.boundingBox != null }
    }

    private fun tapLine(line: Text.Line, done: (Boolean) -> Unit) {
        val b = line.boundingBox ?: return done(false)
        val x = (b.left + b.right) / 2f
        val y = (b.top + b.bottom) / 2f
        if (!AutoAnswerAccessibilityService.tap(x, y, done)) done(false)
    }

    private fun autoAnswerCurrent(answer: String) {
        if (!autoAnswerRunning) return
        val letter = answerLetter(answer)
        val option = letter?.let { findOptionLine(lastOcr, it) }
        if (letter == null || option == null) {
            autoAnswerRunning = false
            setStatus("Auto berhenti: opsi tidak pasti")
            toast("Opsi jawaban tidak terdeteksi dengan aman. Auto jawab dihentikan.")
            return
        }
        setStatus("Memilih opsi $letter…")
        // Hilangkan panel/bubble supaya gesture tidak mengenai overlay milik kita sendiri.
        closeTransient()
        bubble?.visibility = View.INVISIBLE; windows.setVisible(false); drawView?.visibility = View.INVISIBLE
        main.postDelayed({
            tapLine(option) { ok -> main.post optionTap@{
                bubble?.visibility = View.VISIBLE; windows.setVisible(true); drawView?.visibility = View.VISIBLE
                if (!autoAnswerRunning) return@optionTap
                if (!ok) {
                    autoAnswerRunning = false; setStatus("Gagal mengetuk opsi")
                    toast("Gagal mengetuk opsi. Pastikan izin aksesibilitas aktif.")
                    return@optionTap
                }
                // Beri aplikasi target waktu memproses pilihan, lalu cari tombol lanjut yang benar-benar terlihat.
                main.postDelayed({
                    if (!autoAnswerRunning) return@postDelayed
                    setStatus("Mencari tombol lanjut…")
                    grab { bmp ->
                        if (bmp == null) { stopAutoWithMessage("Gagal membaca layar setelah memilih jawaban."); return@grab }
                        ocr(bmp) { screenText ->
                            val next = findNextLine(screenText)
                            if (next == null) {
                                stopAutoWithMessage("Tombol Lanjutkan/Next tidak terdeteksi. Auto jawab dihentikan agar tidak mengetuk sembarang area.")
                            } else {
                                closeTransient()
                                bubble?.visibility = View.INVISIBLE; windows.setVisible(false); drawView?.visibility = View.INVISIBLE
                                main.postDelayed({
                                    tapLine(next) { nextOk -> main.post nextTap@{
                                        bubble?.visibility = View.VISIBLE; windows.setVisible(true); drawView?.visibility = View.VISIBLE
                                        if (!autoAnswerRunning) return@nextTap
                                        if (!nextOk) stopAutoWithMessage("Gagal mengetuk tombol lanjut.")
                                        else main.postDelayed({ if (autoAnswerRunning) solve() }, 1000)
                                    } }
                                }, 180)
                            }
                        }
                    }
                }, 700)
            } }
        }, 180)
    }

    private fun stopAutoWithMessage(message: String) {
        autoAnswerRunning = false
        setStatus("Auto jawab dihentikan")
        showAnswer(message)
        toast(message)
    }

    private fun explain() {
        if (lastPrompt.isEmpty()) { toast("Belum ada soal untuk dijelaskan."); return }
        askGemini("explain", lastPrompt + "\n\nJawaban sebelumnya:\n" + answerText, null)
    }

    private fun askGemini(mode: String, text: String, img: Bitmap?) {
        currentCall?.cancel()
        setStatus("Bertanya ke Gemini…"); showAnswer("Berpikir…")
        currentCall = GeminiClient.ask(this, mode, text, img) { r ->
            r.onSuccess { ans ->
                val bad = ans.contains("TIDAK_TERBACA")
                setStatus(if (bad) "Tidak terbaca" else "Selesai")
                showAnswer(if (bad) "Soal tidak terbaca/tidak lengkap. Coba Crop Area atau Scan Ulang." else ans)
                if (mode == "solve" && autoAnswerRunning) {
                    if (bad) stopAutoWithMessage("Soal tidak terbaca dengan cukup yakin. Auto jawab dihentikan.")
                    else autoAnswerCurrent(ans)
                }
                // Riwayat + sinkronisasi dicatat otak Dart saat mode "solve" berhasil.
            }.onFailure {
                if (autoAnswerRunning) autoAnswerRunning = false
                setStatus("Gagal"); showAnswer(it.message ?: "Gagal")
            }
        }
    }

    // ---------- crop ----------
    private val qRe = Regex("""^\s*(\d{1,3}[.)]|\(?[A-Ea-e][.)])\s*\S""")

    private fun smartRect(t: Text?): Rect? {
        var found = false
        val acc = Rect()
        t?.textBlocks?.forEach { b ->
            b.lines.forEach { l ->
                val bb = l.boundingBox
                if (bb != null && (qRe.containsMatchIn(l.text) || l.text.trimEnd().endsWith("?"))) {
                    if (!found) { acc.set(bb); found = true } else acc.union(bb)
                }
            }
        }
        return if (found) acc else null
    }

    fun startCrop(onResult: (Bitmap) -> Unit) {
        setStatus("Menyiapkan crop…")
        ensureCapture {
            grab { bmp ->
                when {
                    bmp == null -> fail("Gagal mengambil layar untuk crop.")
                    ScreenCaptureManager.isBlank(bmp) -> fail("Layar tampak kosong/hitam (mungkin FLAG_SECURE). Capture tidak bisa dipakai di layar ini.")
                    else -> ocr(bmp) { t -> showCrop(bmp, smartRect(t), onResult) }
                }
            }
        }
    }

    private fun showCrop(bmp: Bitmap, initial: Rect?, onResult: (Bitmap) -> Unit) {
        closeCrop()
        val v = CropView(this, bmp, initial, 0xFF22D3EE.toInt()) { r ->
            closeCrop()
            if (r == null) setStatus("Siap") else {
                setStatus("Siap")
                runCatching { Bitmap.createBitmap(bmp, r.left, r.top, r.width(), r.height()) }
                    .onSuccess(onResult).onFailure { toast("Crop gagal, coba lagi.") }
            }
        }
        val p = WindowManager.LayoutParams(
            -1, -1, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28) p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        wm.addView(v, p); cropView = v
    }

    private fun closeCrop() { cropView?.let { runCatching { wm.removeView(it) } }; cropView = null }
    fun closeDraw() { drawView?.let { runCatching { wm.removeView(it) } }; drawView = null }

    private fun payload(bmp: Bitmap, cb: (String, Bitmap?) -> Unit) {
        ocr(bmp) { t ->
            val text = t?.text ?: ""
            Brain.call(this, "prepare", mapOf("text" to text)) { r ->
                val p = r.getOrNull() as? Map<*, *>
                if (p != null && p["readable"] == true && p["needsImage"] != true) cb((p["prompt"] as? String) ?: text, null)
                else cb("Jelaskan atau jawab isi gambar ini.", bmp)
            }
        }
    }

    /** Hasil crop/galeri dikirim ke alat pilihan pengguna (OCR lokal dulu agar hemat kuota). */
    fun chooseTarget(bmp: Bitmap) {
        showMenu(listOf(
            "Tanya Gemini" to { payload(bmp) { t, img -> tools.openGemini(t, img) } },
            "Pencarian" to { ocr(bmp) { tools.openSearch(it?.text?.replace("\n", " ")?.take(150)) } },
            "Terjemahan" to { ocr(bmp) { tools.openTranslate(it?.text ?: "", true) } }
        ))
    }

    // ---------- utilitas ----------
    fun copyText(t: String) {
        if (t.isBlank()) return
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("jawaban", t))
        toast("Disalin")
    }

    private fun speak(t: String) {
        if (t.isBlank()) return
        val engine = tts
        if (engine == null) {
            tts = TextToSpeech(this) { st -> if (st == TextToSpeech.SUCCESS) { tts?.language = Locale("id", "ID"); tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "ans") } }
        } else engine.speak(t, TextToSpeech.QUEUE_FLUSH, null, "ans")
    }

    private fun cleanTemp() { cacheDir.listFiles()?.filter { it.name.startsWith("pick_") }?.forEach { it.delete() } }

    /** Privacy Kill Switch: hentikan capture, batalkan request, tutup jendela, hapus gambar sementara. */
    fun killSwitch() {
        autoAnswerRunning = false
        currentCall?.cancel(); currentCall = null; pendingAfterGrant = null
        capture.release()
        startFg(false) // lepas tipe mediaProjection + perbarui teks notifikasi
        windows.closeAll(); closeCrop(); closeDraw(); closeTransient()
        cleanTemp()
        answerText = ""; lastPrompt = ""; expanded = false
        setStatus("Capture dihentikan")
        toast("Capture dihentikan & gambar sementara dibersihkan")
    }
}
