package com.example.floating_ai_assistant

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import java.io.File
import kotlin.math.max

/** Activity transparan untuk dialog sistem: izin capture, speech-to-text, dan pemilih gambar. */
class TrampolineActivity : Activity() {
    companion object {
        const val KIND = "kind"
        const val ACTION_RESULT = "com.example.floating_ai_assistant.RESULT"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState != null) return // dibuat ulang (mis. rotasi): hasil dialog tetap datang lewat onActivityResult
        try {
            when (intent.getStringExtra(KIND)) {
                "capture" -> startActivityForResult(
                    (getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager).createScreenCaptureIntent(), 1)
                "speech" -> startActivityForResult(
                    Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                        .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID"), 2)
                "pick" -> startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 3)
                else -> finish()
            }
        } catch (e: Exception) {
            reply(intent.getStringExtra(KIND)?.let { mapOf("capture" to 1, "speech" to 2, "pick" to 3)[it] } ?: 0, false, null)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        reply(requestCode, resultCode == RESULT_OK, data, resultCode)
    }

    private fun reply(req: Int, ok: Boolean, data: Intent?, code: Int = 0) {
        val out = Intent(ACTION_RESULT).setPackage(packageName).putExtra("req", req).putExtra("ok", ok)
        if (ok && data != null) when (req) {
            1 -> out.putExtra("code", code).putExtra("data", data)
            2 -> out.putExtra("text", data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull())
            3 -> data.data?.let { uri ->
                val f = File(cacheDir, "pick_${System.currentTimeMillis()}.jpg")
                if (saveScaled(uri, f)) out.putExtra("path", f.absolutePath)
            }
        }
        sendBroadcast(out)
        finish()
    }

    private fun saveScaled(uri: Uri, f: File): Boolean = runCatching {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (max(o.outWidth, o.outHeight) / s > 2200) s *= 2
        val bmp = contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s })
        } ?: return@runCatching false
        f.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        true
    }.getOrDefault(false)
}
