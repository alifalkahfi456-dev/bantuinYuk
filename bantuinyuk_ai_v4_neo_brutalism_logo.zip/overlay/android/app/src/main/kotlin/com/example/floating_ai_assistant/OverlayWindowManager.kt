package com.example.floating_ai_assistant

import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.max
import kotlin.math.min

/** Jendela alat mengambang: judul + ✕ merah, bisa digeser, diubah ukurannya, isi bebas. */
class FloatingWindow(
    private val svc: FloatingOverlayService, val tag: String, title: String, w: Int, h: Int, focusable: Boolean,
    build: (FrameLayout, FloatingWindow) -> Unit, private val onGone: (FloatingWindow) -> Unit
) {
    val root = LinearLayout(svc)
    val lp: WindowManager.LayoutParams
    var cleanup: (() -> Unit)? = null
    private var closed = false

    init {
        val scr = realSize(svc.wm)
        var flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        if (!focusable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        lp = WindowManager.LayoutParams(w, h, overlayType(), flags, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (scr.x - w) / 2; y = svc.px(96)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        }
        root.orientation = LinearLayout.VERTICAL
        root.background = Ui.glass(svc, true, 20, true)
        root.elevation = svc.px(12).toFloat()
        root.setPadding(svc.px(6), svc.px(6), svc.px(6), svc.px(6))

        val bar = LinearLayout(svc).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(svc.px(8), svc.px(4), svc.px(4), svc.px(6)) }
        bar.addView(TextView(svc).apply { text = title; setTextColor(0xFF171717.toInt()); textSize = 14f; typeface = Typeface.DEFAULT_BOLD },
            LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(TextView(svc).apply {
            text = "✕"; setTextColor(0xFFFFFFFF.toInt()); textSize = 13f; gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.RECTANGLE; cornerRadius = svc.px(3).toFloat(); setColor(0xFFFF5C5C.toInt()); setStroke(svc.px(2), 0xFF171717.toInt()) }
            setOnClickListener { close() }
        }, LinearLayout.LayoutParams(svc.px(26), svc.px(26)))
        var sx = 0; var sy = 0; var dx = 0f; var dy = 0f
        bar.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; dx = e.rawX; dy = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = (sx + e.rawX - dx).toInt().coerceIn(-lp.width / 2, scr.x - lp.width / 2)
                    lp.y = (sy + e.rawY - dy).toInt().coerceIn(0, scr.y - svc.px(60))
                    update()
                }
            }
            true
        }
        root.addView(bar)

        val content = FrameLayout(svc)
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))

        val handle = TextView(svc).apply { text = "◢"; setTextColor(0x99FFFFFF.toInt()); textSize = 14f; gravity = Gravity.END; setPadding(0, 0, svc.px(4), 0) }
        var rw = 0; var rh = 0; var rx = 0f; var ry = 0f
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { rw = lp.width; rh = lp.height; rx = e.rawX; ry = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    lp.width = (rw + e.rawX - rx).toInt().coerceIn(svc.px(220), min(scr.x, svc.px(520)))
                    lp.height = (rh + e.rawY - ry).toInt().coerceIn(svc.px(160), (scr.y * 0.9f).toInt())
                    update()
                }
            }
            true
        }
        root.addView(handle, LinearLayout.LayoutParams(-1, -2))
        build(content, this)
        svc.wm.addView(root, lp)
    }

    fun update() { if (!closed) runCatching { svc.wm.updateViewLayout(root, lp) } }

    fun bringToFront() { runCatching { svc.wm.removeView(root); svc.wm.addView(root, lp) } }

    fun close() {
        if (closed) return
        closed = true
        runCatching { cleanup?.invoke() }
        runCatching { svc.wm.removeView(root) }
        onGone(this)
    }
}

class OverlayWindowManager(private val svc: FloatingOverlayService) {
    private val list = mutableListOf<FloatingWindow>()
    private val maxWindows = 3

    fun open(tag: String, title: String, w: Int, h: Int, focusable: Boolean, build: (FrameLayout, FloatingWindow) -> Unit): FloatingWindow? {
        list.firstOrNull { it.tag == tag }?.let { it.bringToFront(); return it }
        if (list.size >= maxWindows) {
            Toast.makeText(svc, "Maksimal $maxWindows jendela. Tutup salah satu dulu.", Toast.LENGTH_SHORT).show()
            return null
        }
        val win = FloatingWindow(svc, tag, title, w, h, focusable, build) { list.remove(it) }
        list.add(win)
        return win
    }

    fun close(tag: String) { list.firstOrNull { it.tag == tag }?.close() }
    fun setVisible(v: Boolean) { list.forEach { it.root.visibility = if (v) View.VISIBLE else View.INVISIBLE } }
    fun closeAll() { list.toList().forEach { it.close() } }
}
