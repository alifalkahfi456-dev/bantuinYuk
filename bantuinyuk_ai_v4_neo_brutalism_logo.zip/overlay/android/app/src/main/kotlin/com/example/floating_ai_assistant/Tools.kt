package com.example.floating_ai_assistant

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import java.net.URLEncoder

/** Isi jendela alat: Pencarian, Tanya Gemini, Terjemahan, Gambar, Galeri, dan Pengaturan Bubble. */
class Tools(private val s: FloatingOverlayService) {
    private val white = 0xFF171717.toInt()
    private fun col() = LinearLayout(s).apply { orientation = LinearLayout.VERTICAL }
    private fun lpl(w: Int = -1, h: Int = -2, wt: Float = 0f) = LinearLayout.LayoutParams(w, h, wt)

    private fun edit(hint: String, lines: Int) = EditText(s).apply {
        this.hint = hint; setHintTextColor(0x88171717.toInt()); setTextColor(white); textSize = 14f; maxLines = lines
        setPadding(s.px(10), s.px(8), s.px(10), s.px(8))
        background = GradientDrawable().apply { cornerRadius = s.px(3).toFloat(); setColor(0xFFFFFFFF.toInt()); setStroke(s.px(2), 0xFF171717.toInt()) }
    }

    private fun iconBtn(t: String, onClick: () -> Unit) = TextView(s).apply {
        text = t; textSize = 18f; setTextColor(white); gravity = Gravity.CENTER
        setPadding(s.px(8), s.px(6), s.px(8), s.px(6)); setOnClickListener { onClick() }
    }

    private fun answerView() = TextView(s).apply {
        setTextColor(white); textSize = 14f; setPadding(s.px(10), s.px(8), s.px(10), s.px(8)); setTextIsSelectable(true)
    }

    fun openGemini(initialText: String? = null, initialImg: Bitmap? = null) {
        if (initialText != null || initialImg != null) s.windows.close("gemini")
        s.windows.open("gemini", "Tanya Gemini", s.px(300), s.px(400), true) { frame, win ->
            var attached: Bitmap? = initialImg
            var call: GeminiClient.Call? = null
            val root = col()
            val ans = answerView().apply { text = "Tanyakan sesuatu atau lampirkan gambar." }
            root.addView(ScrollView(s).apply { addView(ans) }, lpl(-1, 0, 1f))
            val thumb = ImageView(s).apply { scaleType = ImageView.ScaleType.CENTER_CROP; visibility = View.GONE }
            root.addView(thumb, lpl(s.px(56), s.px(56)))
            fun refreshThumb() { thumb.visibility = if (attached != null) View.VISIBLE else View.GONE; thumb.setImageBitmap(attached) }
            val input = edit("Tanyakan apa saja", 3)
            fun send(q: String) {
                if (q.isBlank() && attached == null) return
                call?.cancel(); ans.text = "Berpikir…"
                call = GeminiClient.ask(s, "ask", q, attached) { r -> ans.text = r.fold({ Ui.md(it) }, { it.message ?: "Gagal" }) }
                input.setText("")
            }
            val bar = LinearLayout(s).apply { gravity = Gravity.CENTER_VERTICAL }
            bar.addView(input, lpl(0, -2, 1f))
            bar.addView(iconBtn("🎤") { s.requestSpeech { t -> input.setText(t) } })
            bar.addView(iconBtn("✂") { s.startCrop { b -> attached = b; refreshThumb() } })
            bar.addView(iconBtn("🖼") { s.requestPick { b -> attached = b; refreshThumb() } })
            bar.addView(iconBtn("➤") { send(input.text.toString().trim()) })
            root.addView(bar)
            frame.addView(root, FrameLayout.LayoutParams(-1, -1))
            win.cleanup = { call?.cancel() }
            refreshThumb()
            if (initialText != null || initialImg != null) send(initialText ?: "")
        }
    }

    fun openSearch(query: String? = null) {
        if (!query.isNullOrBlank()) s.windows.close("search")
        s.windows.open("search", "Pencarian", s.px(320), s.px(420), true) { frame, win ->
            val root = col()
            val input = edit("Cari atau ketik URL", 1).apply { setSingleLine(true); setText(query ?: "") }
            val wv = WebView(s)
            wv.settings.javaScriptEnabled = true
            wv.webViewClient = WebViewClient()
            fun go(q: String) {
                val t = q.trim(); if (t.isEmpty()) return
                wv.loadUrl(if (t.startsWith("http")) t else "https://www.google.com/search?q=" + URLEncoder.encode(t, "UTF-8"))
            }
            val bar = LinearLayout(s).apply { gravity = Gravity.CENTER_VERTICAL }
            bar.addView(input, lpl(0, -2, 1f)); bar.addView(iconBtn("🔍") { go(input.text.toString()) })
            root.addView(bar); root.addView(wv, lpl(-1, 0, 1f))
            frame.addView(root, FrameLayout.LayoutParams(-1, -1))
            win.cleanup = {
                wv.stopLoading(); wv.loadUrl("about:blank")
                (wv.parent as? ViewGroup)?.removeView(wv); wv.destroy()
            }
            if (!query.isNullOrBlank()) go(query)
        }
    }

    fun openTranslate(text: String? = null, auto: Boolean = false) {
        if (text != null) s.windows.close("translate")
        s.windows.open("translate", "Terjemahan", s.px(300), s.px(380), true) { frame, win ->
            var call: GeminiClient.Call? = null
            val root = col()
            val input = edit("Ketik atau tempel teks", 6).apply { setText(text ?: ""); gravity = Gravity.TOP }
            val ans = answerView()
            var plain = ""
            fun doTranslate() {
                val t = input.text.toString().trim(); if (t.isEmpty()) return
                call?.cancel(); ans.text = "Menerjemahkan…"
                call = GeminiClient.ask(s, "translate", t, null) { r ->
                    r.onSuccess { plain = it; ans.text = Ui.md(it) }.onFailure { ans.text = it.message ?: "Gagal" }
                }
            }
            root.addView(input, lpl(-1, s.px(110)))
            val bar = LinearLayout(s).apply { gravity = Gravity.CENTER_VERTICAL }
            bar.addView(iconBtn("🎤") { s.requestSpeech { t -> input.setText(t) } })
            bar.addView(Ui.chip(s, "Terjemahkan", white) { doTranslate() }.apply { layoutParams = lpl(0, -2, 1f) })
            bar.addView(iconBtn("📋") { if (plain.isNotEmpty()) s.copyText(plain) })
            root.addView(bar)
            root.addView(ScrollView(s).apply { addView(ans) }, lpl(-1, 0, 1f))
            frame.addView(root, FrameLayout.LayoutParams(-1, -1))
            win.cleanup = { call?.cancel() }
            if (auto && !text.isNullOrBlank()) doTranslate()
        }
    }

    fun openGallery() { s.requestPick { s.chooseTarget(it) } }

    fun openDraw() {
        s.closeDraw()
        val frame = FrameLayout(s)
        val dv = DrawView(s)
        frame.addView(dv, FrameLayout.LayoutParams(-1, -1))
        val bar = LinearLayout(s).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(s.px(10), s.px(6), s.px(10), s.px(6))
            background = Ui.glass(s, true, 20, true)
        }
        listOf(0xFFEF4444.toInt(), 0xFFFACC15.toInt(), 0xFF22D3EE.toInt(), 0xFFFFFFFF.toInt()).forEach { c ->
            bar.addView(View(s).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c); setStroke(s.px(2), 0x99FFFFFF.toInt()) }
                setOnClickListener { dv.color = c }
            }, lpl(s.px(28), s.px(28)).apply { marginEnd = s.px(8) })
        }
        listOf("S" to 3f, "M" to 6f, "L" to 12f).forEach { (l, w) -> bar.addView(iconBtn(l) { dv.widthPx = w * s.d }) }
        bar.addView(iconBtn("↶") { dv.undo() })
        bar.addView(iconBtn("🗑") { dv.clear() })
        bar.addView(iconBtn("✕") { s.closeDraw() })
        frame.addView(bar, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = s.px(48) })
        val p = WindowManager.LayoutParams(
            -1, -1, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        s.wm.addView(frame, p)
        s.drawView = frame
    }

    fun openSettings() {
        s.windows.open("settings", "Pengaturan Bubble", s.px(300), s.px(430), false) { frame, _ ->
            val root = col().apply { setPadding(s.px(8), s.px(4), s.px(8), s.px(8)) }
            fun label(t: String) = TextView(s).apply { text = t; setTextColor(white); textSize = 13f; setPadding(0, s.px(10), 0, s.px(4)) }
            fun seek(max: Int, init: Int, onChange: (Int) -> Unit) = SeekBar(s).apply {
                this.max = max; progress = init
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(b: SeekBar?, p: Int, fromUser: Boolean) { if (fromUser) onChange(p) }
                    override fun onStartTrackingTouch(b: SeekBar?) {}
                    override fun onStopTrackingTouch(b: SeekBar?) {}
                })
            }
            val ok = Settings.canDrawOverlays(s)
            root.addView(label(if (ok) "Izin overlay: ✓ Aktif" else "Izin overlay: Belum aktif"))
            if (!ok) root.addView(Ui.chip(s, "Buka Pengaturan", white) {
                s.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${s.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            })
            root.addView(label("Aksesibilitas: tidak dipakai aplikasi ini"))
            root.addView(label("Bentuk"))
            val shapes = LinearLayout(s)
            listOf("Lingkaran", "Kotak", "Bulat", "Segitiga").forEachIndexed { i, n ->
                shapes.addView(Ui.chip(s, n, white) { s.editStyle { putInt("shape", i) } }.apply {
                    textSize = 11f; setPadding(s.px(4), s.px(8), s.px(4), s.px(8)); layoutParams = lpl(0, -2, 1f).apply { marginEnd = s.px(4) }
                })
            }
            root.addView(shapes)
            root.addView(label("Warna"))
            val colors = LinearLayout(s)
            listOf(0xFFFFD93D, 0xFFFF6B6B, 0xFF6BCB77, 0xFF4D96FF, 0xFFFF8FAB).forEach { c ->
                colors.addView(View(s).apply {
                    background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c.toInt()) }
                    setOnClickListener { s.editStyle { putInt("color", c.toInt()) } }
                }, lpl(s.px(30), s.px(30)).apply { marginEnd = s.px(10) })
            }
            colors.addView(iconBtn("Reset") {
                s.editStyle { putInt("color", 0xFFFFD93D.toInt()); putInt("shape", 0); putInt("size", 64); putFloat("alpha", 0.85f); putBoolean("stealth", false) }
            }.apply { textSize = 12f })
            root.addView(colors)
            root.addView(label("Ukuran"))
            root.addView(seek(48, s.prefs.getInt("size", 64) - 48) { s.editStyle { putInt("size", it + 48) } })
            root.addView(label("Transparansi"))
            root.addView(seek(70, (s.prefs.getFloat("alpha", 0.85f) * 100).toInt() - 30) { s.editStyle { putFloat("alpha", (it + 30) / 100f) } })
            root.addView(Ui.chip(s, if (s.prefs.getBoolean("stealth", false)) "Tampilkan bola normal" else "Sembunyikan bola (transparan)", white) {
                s.editStyle { putBoolean("stealth", !s.prefs.getBoolean("stealth", false)) }
            })
            frame.addView(ScrollView(s).apply { addView(root) }, FrameLayout.LayoutParams(-1, -1))
        }
    }
}
