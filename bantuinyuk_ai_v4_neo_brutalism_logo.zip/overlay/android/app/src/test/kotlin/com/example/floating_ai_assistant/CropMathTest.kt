package com.example.floating_ai_assistant

import org.junit.Assert.*
import org.junit.Test

class CropMathTest {
    @Test fun cropMapsToOriginalResolution() {
        val r = CropMath.toBitmapRect(100f, 200f, 300f, 400f, 1000, 2000, 2000, 4000)
        assertArrayEquals(intArrayOf(200, 400, 600, 800), r)
    }
    @Test fun cropIsClamped() {
        val r = CropMath.toBitmapRect(-5f, -5f, 5000f, 5000f, 1000, 2000, 1000, 2000)
        assertArrayEquals(intArrayOf(0, 0, 1000, 2000), r)
    }
}
